#!/usr/bin/env python3
"""Resolve the bot-swarm project slug for a working directory.

Reads ``$BOT_SQUAD/config/projects.toml`` (falls back to
``/home/www/bot-squad/config/projects.toml``) and matches the cwd
against each project's ``repo_path`` / ``repo_master``. Prints the
slug on stdout if matched; exits 0 with no output otherwise.

Pulled out of session_start.sh + stop.sh so the inline
heredoc-in-`$(...)` pattern doesn't trip bash 3.2's parser on macOS.

Usage:
    python3 _resolve_slug.py [<config-path> [<cwd>]]
Env fallbacks:
    BOT_SQUAD  → install root, used if no config-path arg
    PWD        → used if no cwd arg
"""
from __future__ import annotations

import os
import sys
import tomllib


def main(argv: list[str]) -> int:
    if len(argv) >= 2:
        cfg_path = argv[1]
    else:
        bot_squad = os.environ.get("BOT_SQUAD", "/home/www/bot-squad")
        cfg_path = os.path.join(bot_squad, "config", "projects.toml")

    cwd = argv[2] if len(argv) >= 3 else os.getcwd()

    try:
        with open(cfg_path, "rb") as f:
            cfg = tomllib.load(f)
    except (FileNotFoundError, PermissionError, tomllib.TOMLDecodeError):
        return 0

    real_cwd = os.path.realpath(cwd)

    def _match(target: str) -> bool:
        if not target:
            return False
        real_target = os.path.realpath(target)
        return (
            cwd == target
            or cwd.startswith(target.rstrip("/") + "/")
            or real_cwd == real_target
            or real_cwd.startswith(real_target.rstrip("/") + "/")
        )

    for slug, project in cfg.get("projects", {}).items():
        for key in ("repo_path", "repo_master"):
            if _match(project.get(key, "")):
                print(slug)
                return 0
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
