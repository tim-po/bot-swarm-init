"""Bot-swarm endpoints — swarm operations (sleep / respawn / list).

Thin HTTP wrappers around the worker actions. Authenticated via the
same ``require_auth`` dependency used elsewhere. Dispatches through the
``WorkerRouter`` so the action lands on the caller's own user worker.
"""
from __future__ import annotations

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from app.routes_auth import require_auth
from app.worker_client import WorkerError, WorkerRouter

log = logging.getLogger(__name__)

router = APIRouter(
    prefix="/projects/{slug}",
    tags=["swarm"],
    dependencies=[Depends(require_auth)],
)


def _router(request: Request) -> WorkerRouter:
    return request.app.state.worker_router


def _check_project(request: Request, slug: str) -> None:
    cfg = request.app.state.api_config
    if cfg.project(slug) is None:
        raise HTTPException(status_code=404, detail=f"unknown project: {slug}")


async def _call(request: Request, user: dict, action: str, params: dict) -> dict:
    """Dispatch a swarm worker action via the caller's user-worker."""
    wrouter = _router(request)
    client = wrouter.for_user(user["linux_user"])
    try:
        return await client.call_action(action, params)
    except WorkerError as e:
        raise HTTPException(status_code=502, detail=str(e))


# ---------------------------------------------------------------------------
# Sleep / respawn — session lifecycle
# ---------------------------------------------------------------------------

@router.post("/sessions/{sid}/sleep")
async def sleep_expert(slug: str, sid: str, request: Request,
                       user: dict = Depends(require_auth)) -> dict:
    """Compact this expert's recent transcript into its memory files.
    The pane keeps running; the next respawn loads the updated memory.
    """
    _check_project(request, slug)
    return await _call(request, user, "sleep_expert",
                       {"slug": slug, "sid": sid})


@router.post("/sessions/{sid}/respawn")
async def respawn_expert(slug: str, sid: str, request: Request,
                         user: dict = Depends(require_auth)) -> dict:
    """Kill this pane and spawn a fresh one with the same role.
    Unread mail in the old SID's inbox migrates to the role's holding
    inbox. Returns ``old_sid`` and ``new_sid``.
    """
    _check_project(request, slug)
    return await _call(request, user, "respawn_expert",
                       {"slug": slug, "sid": sid})


@router.post("/sessions/{sid}/sleep-and-respawn")
async def sleep_and_respawn(slug: str, sid: str, request: Request,
                            user: dict = Depends(require_auth)) -> dict:
    """Sleep, then respawn — the canonical "compact and reset" cycle."""
    _check_project(request, slug)
    return await _call(request, user, "sleep_and_respawn",
                       {"slug": slug, "sid": sid})


# ---------------------------------------------------------------------------
# Read-only state surface — what the dashboard reads
# ---------------------------------------------------------------------------

@router.get("/initiatives")
async def list_initiatives(slug: str, request: Request,
                           user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "list_initiatives", {"slug": slug})


@router.get("/initiatives/{id}")
async def read_initiative(slug: str, id: str, request: Request,
                          user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "read_initiative",
                       {"slug": slug, "id": id})


@router.get("/tasks")
async def list_tasks(slug: str, request: Request,
                     user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "list_tasks", {"slug": slug})


@router.get("/tasks/{id}")
async def read_task(slug: str, id: str, request: Request,
                    user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "read_task",
                       {"slug": slug, "id": id})


@router.get("/experts")
async def list_experts(slug: str, request: Request,
                       user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "list_experts", {"slug": slug})


@router.get("/experts/{role}/memory/{filename}")
async def read_expert_memory(slug: str, role: str, filename: str, request: Request,
                             user: dict = Depends(require_auth)) -> dict:
    """Read one memory file belonging to a swarm expert."""
    _check_project(request, slug)
    return await _call(request, user, "read_expert_memory",
                       {"slug": slug, "role": role, "filename": filename})


@router.post("/bootstrap-repo")
async def bootstrap_repo(slug: str, request: Request,
                         user: dict = Depends(require_auth)) -> dict:
    """Drop a swarm-aware .claude/settings.json into the project's
    repo_path. Idempotent — leaves an existing settings.json alone.
    """
    _check_project(request, slug)
    return await _call(request, user, "bootstrap_project_repo", {"slug": slug})


# ---------------------------------------------------------------------------
# Strategy — writable config the dashboard tunes
# ---------------------------------------------------------------------------

from pydantic import BaseModel


class StrategyPatch(BaseModel):
    # Partial dict of strategy keys to update. Worker validates exact
    # keys + types and rejects unknown ones.
    patch: dict


@router.get("/strategy")
async def get_strategy(slug: str, request: Request,
                       user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "get_strategy", {"slug": slug})


@router.put("/strategy")
async def set_strategy(slug: str, body: StrategyPatch, request: Request,
                       user: dict = Depends(require_auth)) -> dict:
    _check_project(request, slug)
    return await _call(request, user, "set_strategy",
                       {"slug": slug, "patch": body.patch})
