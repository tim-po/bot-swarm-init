"""Inbox endpoints — read-only views over the personal-TG SQLite db.

The db is written by ``worker/bot_squad_worker/tg_user.py`` (a separate
process). We open it read-only here; SQLite WAL mode handles the
concurrent-reader case cleanly. If the worker has never run, the file
won't exist yet — endpoints return empty lists, not 500.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, Request

from app.routes_auth import require_auth


router = APIRouter(
    prefix="/tg",
    tags=["tg-inbox"],
    dependencies=[Depends(require_auth)],
)


def _db_path(request: Request) -> Path:
    # api/app/main.py stashes data_dir on app.state via heartbeat_path's parent.
    # Reuse that anchor rather than re-parsing env.
    heartbeat: Path = request.app.state.heartbeat_path
    data_dir = heartbeat.parent.parent  # data/_worker/heartbeat → data/
    return data_dir / "_tg" / "messages.db"


def _open_ro(path: Path) -> Optional[sqlite3.Connection]:
    if not path.exists():
        return None
    # uri=True lets us pass mode=ro; the db file stays untouched.
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


@router.get("/chats")
def list_chats(request: Request) -> dict:
    """List distinct chats with message counts and last-seen timestamp."""
    conn = _open_ro(_db_path(request))
    if conn is None:
        return {"chats": [], "db_present": False}
    try:
        rows = conn.execute(
            """
            SELECT
                c.chat_id            AS chat_id,
                c.title              AS title,
                c.kind               AS kind,
                c.last_msg_id        AS last_msg_id,
                c.updated_at         AS updated_at,
                COALESCE(m.cnt, 0)   AS message_count
            FROM chats c
            LEFT JOIN (
                SELECT chat_id, COUNT(*) AS cnt
                FROM messages
                GROUP BY chat_id
            ) m ON m.chat_id = c.chat_id
            ORDER BY c.updated_at DESC
            """
        ).fetchall()
        return {
            "db_present": True,
            "chats": [dict(r) for r in rows],
        }
    finally:
        conn.close()


@router.get("/messages")
def list_messages(
    request: Request,
    chat_id: Optional[int] = None,
    before_ts: Optional[int] = None,
    limit: int = 50,
) -> dict:
    """Page of messages, newest first.

    Cursor: pass the oldest ``ts`` you've seen as ``before_ts`` to fetch the
    next page. ``chat_id`` filters to one chat.
    """
    limit = max(1, min(int(limit), 200))
    conn = _open_ro(_db_path(request))
    if conn is None:
        return {"messages": [], "db_present": False}
    try:
        clauses, args = [], []
        if chat_id is not None:
            clauses.append("chat_id = ?")
            args.append(int(chat_id))
        if before_ts is not None:
            clauses.append("ts < ?")
            args.append(int(before_ts))
        where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
        sql = f"""
            SELECT chat_id, msg_id, ts, chat_title, sender_id, sender_name,
                   text, project, status
            FROM messages
            {where}
            ORDER BY ts DESC, msg_id DESC
            LIMIT ?
        """
        args.append(limit)
        rows = conn.execute(sql, args).fetchall()
        return {
            "db_present": True,
            "messages": [dict(r) for r in rows],
            "next_before_ts": rows[-1]["ts"] if len(rows) == limit else None,
        }
    finally:
        conn.close()
