"""Tests for /api/projects/{slug}/{sleep,respawn,initiatives,tasks,experts}."""
from __future__ import annotations

import threading
import time
from pathlib import Path

import pytest
import uvicorn
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.main import build_app


@pytest.fixture
def fake_worker_swarm(tmp_bot_squad: Path):
    """Fake worker that records every swarm action call and returns
    canned responses."""
    sock = tmp_bot_squad / "data" / "_sock" / "worker.sock"
    sock.parent.mkdir(parents=True, exist_ok=True)

    fake = FastAPI()
    calls: list[tuple[str, dict]] = []

    @fake.post("/actions/sleep_expert")
    def sleep_expert(params: dict | None = None) -> dict:
        calls.append(("sleep_expert", params or {}))
        return {"ok": True, "role": "coordinator", "compacted_bytes": 1234,
                "mark_before": 0, "mark_after": 1234, "scribe_stdout_tail": ""}

    @fake.post("/actions/respawn_expert")
    def respawn_expert(params: dict | None = None) -> dict:
        calls.append(("respawn_expert", params or {}))
        return {"ok": True, "old_sid": "S-x-y-p1", "new_sid": "S-x-y-p2",
                "role": "backend-expert", "window": "y", "drained_lines": 0}

    @fake.post("/actions/sleep_and_respawn")
    def sleep_and_respawn(params: dict | None = None) -> dict:
        calls.append(("sleep_and_respawn", params or {}))
        return {"ok": True, "role": "coordinator", "compacted_bytes": 9,
                "old_sid": "S-x-y-p1", "new_sid": "S-x-y-p2",
                "drained_lines": 0, "window": "y"}

    @fake.post("/actions/list_initiatives")
    def list_initiatives(params: dict | None = None) -> dict:
        calls.append(("list_initiatives", params or {}))
        return {"ok": True, "initiatives": [
            {"id": "I-0001", "title": "Stash MVP", "status": "active",
             "related_tasks": ["T-0001"], "created_at": "2026-05-18",
             "owner": "coordinator", "path": "/x", "extra": {}},
        ]}

    @fake.post("/actions/read_initiative")
    def read_initiative(params: dict | None = None) -> dict:
        calls.append(("read_initiative", params or {}))
        return {"ok": True, "id": params["id"], "frontmatter": {"id": params["id"]},
                "body": "## Goal\nThe goal.\n", "path": "/x"}

    @fake.post("/actions/list_tasks")
    def list_tasks(params: dict | None = None) -> dict:
        calls.append(("list_tasks", params or {}))
        return {"ok": True, "tasks": [
            {"id": "T-0001", "title": "Backend skeleton", "initiative_id": "I-0001",
             "assigned_role": "backend-expert", "status": "ready",
             "depends_on": [], "created_at": "2026-05-18", "path": "/x", "extra": {}},
        ]}

    @fake.post("/actions/read_task")
    def read_task(params: dict | None = None) -> dict:
        calls.append(("read_task", params or {}))
        return {"ok": True, "id": params["id"], "frontmatter": {"id": params["id"]},
                "body": "## Done when\n- ...\n", "path": "/x"}

    @fake.post("/actions/list_experts")
    def list_experts(params: dict | None = None) -> dict:
        calls.append(("list_experts", params or {}))
        return {"ok": True, "experts": [
            {"role": "coordinator", "has_identity": True,
             "memory_files": ["MEMORY.md", "roster.md"], "sleep_mark": 12345,
             "archived": False},
        ]}

    @fake.post("/actions/get_strategy")
    def get_strategy(params: dict | None = None) -> dict:
        calls.append(("get_strategy", params or {}))
        return {"ok": True, "strategy": {
            "auto_sleep_enabled": False,
            "auto_sleep_threshold_bytes": 200000,
            "auto_sleep_min_interval_sec": 600,
            "auto_sleep_respawn": True,
            "auto_sleep_includes_coordinator": False,
        }}

    @fake.post("/actions/set_strategy")
    def set_strategy(params: dict | None = None) -> dict:
        calls.append(("set_strategy", params or {}))
        return {"ok": True, "strategy": {
            "auto_sleep_enabled": True,
            "auto_sleep_threshold_bytes": 200000,
            "auto_sleep_min_interval_sec": 600,
            "auto_sleep_respawn": True,
            "auto_sleep_includes_coordinator": False,
        }}

    config = uvicorn.Config(fake, uds=str(sock), log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(50):
        if sock.exists():
            break
        time.sleep(0.05)

    yield sock, calls

    server.should_exit = True
    thread.join(timeout=5)


def _client(tmp_bot_squad: Path, monkeypatch, sock_path: Path):
    monkeypatch.setenv("CONFIG_DIR", str(tmp_bot_squad / "config"))
    monkeypatch.setenv("DATA_DIR", str(tmp_bot_squad / "data"))
    monkeypatch.setenv("WORKER_SOCK", str(sock_path))
    monkeypatch.setenv("JWT_SECRET", "test-secret")
    monkeypatch.setenv("COOKIE_SECURE", "0")
    client = TestClient(build_app())
    client.post("/api/auth/login", json={"username": "testuser", "password": "test"})
    return client


# ---------------------------------------------------------------------------
# Sleep / respawn lifecycle endpoints
# ---------------------------------------------------------------------------

def test_sleep_route_dispatches_to_worker(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.post("/api/projects/test-project/sessions/S-u-coord-p1/sleep")
    assert r.status_code == 200, r.text
    assert r.json()["compacted_bytes"] == 1234
    assert ("sleep_expert", {"slug": "test-project", "sid": "S-u-coord-p1"}) in calls


def test_respawn_route_dispatches_to_worker(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.post("/api/projects/test-project/sessions/S-u-coord-p1/respawn")
    assert r.status_code == 200
    body = r.json()
    assert body["new_sid"] == "S-x-y-p2"
    assert ("respawn_expert", {"slug": "test-project", "sid": "S-u-coord-p1"}) in calls


def test_sleep_and_respawn_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.post("/api/projects/test-project/sessions/S-u-coord-p1/sleep-and-respawn")
    assert r.status_code == 200
    assert r.json()["new_sid"] == "S-x-y-p2"
    assert ("sleep_and_respawn", {"slug": "test-project", "sid": "S-u-coord-p1"}) in calls


# ---------------------------------------------------------------------------
# Read-only state endpoints
# ---------------------------------------------------------------------------

def test_list_initiatives_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/initiatives")
    assert r.status_code == 200
    inits = r.json()["initiatives"]
    assert len(inits) == 1
    assert inits[0]["id"] == "I-0001"
    assert ("list_initiatives", {"slug": "test-project"}) in calls


def test_read_initiative_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/initiatives/I-0001")
    assert r.status_code == 200
    assert "## Goal" in r.json()["body"]
    assert ("read_initiative", {"slug": "test-project", "id": "I-0001"}) in calls


def test_list_tasks_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/tasks")
    assert r.status_code == 200
    tasks = r.json()["tasks"]
    assert tasks[0]["assigned_role"] == "backend-expert"
    assert ("list_tasks", {"slug": "test-project"}) in calls


def test_read_task_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/tasks/T-0001")
    assert r.status_code == 200
    assert ("read_task", {"slug": "test-project", "id": "T-0001"}) in calls


def test_list_experts_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/experts")
    assert r.status_code == 200
    experts = r.json()["experts"]
    assert experts[0]["role"] == "coordinator"
    assert experts[0]["sleep_mark"] == 12345
    assert ("list_experts", {"slug": "test-project"}) in calls


def test_unknown_project_returns_404(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, _ = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/no-such-project/initiatives")
    assert r.status_code == 404


def test_get_strategy_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.get("/api/projects/test-project/strategy")
    assert r.status_code == 200
    body = r.json()["strategy"]
    assert body["auto_sleep_enabled"] is False
    assert body["auto_sleep_threshold_bytes"] == 200000
    assert ("get_strategy", {"slug": "test-project"}) in calls


def test_set_strategy_route(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, calls = fake_worker_swarm
    with _client(tmp_bot_squad, monkeypatch, sock) as c:
        r = c.put("/api/projects/test-project/strategy",
                  json={"patch": {"auto_sleep_enabled": True}})
    assert r.status_code == 200, r.text
    assert r.json()["strategy"]["auto_sleep_enabled"] is True
    assert ("set_strategy", {"slug": "test-project",
                             "patch": {"auto_sleep_enabled": True}}) in calls


def test_unauthenticated_request_rejected(tmp_bot_squad, monkeypatch, fake_worker_swarm):
    sock, _ = fake_worker_swarm
    monkeypatch.setenv("CONFIG_DIR", str(tmp_bot_squad / "config"))
    monkeypatch.setenv("DATA_DIR", str(tmp_bot_squad / "data"))
    monkeypatch.setenv("WORKER_SOCK", str(sock))
    monkeypatch.setenv("JWT_SECRET", "test-secret")
    monkeypatch.setenv("COOKIE_SECURE", "0")
    anon = TestClient(build_app())
    r = anon.get("/api/projects/test-project/initiatives")
    assert r.status_code in (401, 403)
