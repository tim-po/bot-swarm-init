"""Config loader — parses bot-squad config/projects.toml + config/secrets.toml."""
from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path


class ConfigError(Exception):
    """Raised when projects.toml/secrets.toml is missing, malformed, or
    incomplete. Carries a human-readable, multi-field detail so the worker
    can surface *which* file and *which* keys are wrong in degraded mode
    instead of crash-looping on the first KeyError."""


# Required keys every project entry must define. Anything not listed here is
# optional (prod_url/staging_url/dev_url default to ""; repo_master to None).
_PROJECT_REQUIRED = (
    "slug",
    "display_name",
    "repo_path",
    "deploy_branch",
    "master_branch",
    "deploy_targets",
    "tg_chat",
)


@dataclass(frozen=True)
class Project:
    slug: str
    display_name: str
    repo_path: Path           # alias for repo_dev — the dev clone
    deploy_branch: str
    master_branch: str
    prod_url: str
    staging_url: str
    dev_url: str
    deploy_targets: tuple[str, ...]
    tg_chat: str
    repo_master: Path | None = None  # master clone for prod deploys + hotfixes
    # Per-project Telegram bot toggle. When False the multi-bot listener does
    # NOT poll this project's bot (its getUpdates loop is skipped entirely), so
    # a newly-registered project stays dark until the coordinator flips it on.
    # Sourced from a ``[projects.<slug>.tg]`` sub-table (``enabled = true``) or a
    # top-level ``tg_enabled`` key in the project entry; see ``from_toml``.
    tg_enabled: bool = False
    # Per-project per-user authorization opt-in. Default False so existing
    # projects (notably the LIVE 'computation' bot) keep their byte-for-byte
    # historical chat-level-only behavior: no identity resolution, no per-user
    # rate limit, no new gating, no new slash commands. ONLY when a project sets
    # ``tg_authz = true`` (e.g. swarmdev) does tg_authz.py engage in the
    # listener. Parsed exactly like ``tg_enabled`` (sub-table or flat key).
    tg_authz: bool = False

    def repo_for_target(self, target: str) -> Path:
        """Pick the right clone for a deploy target.

        - ``prod``: master clone (separate dir so dev work continues
          uninterrupted while a prod deploy is in flight). Falls back to
          ``repo_path`` if ``repo_master`` is not configured.
        - everything else (``staging``, ``dev``, …): dev clone = ``repo_path``.
        """
        if target == "prod" and self.repo_master is not None:
            return self.repo_master
        return self.repo_path

    @classmethod
    def from_toml(cls, raw: dict, slug_hint: str | None = None) -> "Project":
        """Build a Project from a raw projects.toml table.

        Collects *all* missing required keys into one ConfigError rather than
        bailing on the first KeyError, so a degraded worker can report e.g.
        "project 'swarmdev': missing required keys: deploy_branch, tg_chat".
        ``slug_hint`` is the table key (used in the message when the entry
        omits its own ``slug``).
        """
        missing = [k for k in _PROJECT_REQUIRED if k not in raw]
        if missing:
            name = raw.get("slug") or slug_hint or "<unknown>"
            raise ConfigError(
                f"project {name!r}: missing required keys: " + ", ".join(missing)
            )
        # tg_enabled: accept either a [projects.<slug>.tg] sub-table with
        # ``enabled = true`` (preferred, groups future per-project TG settings)
        # or a flat ``tg_enabled`` key. Default False — projects stay dark until
        # explicitly enabled.
        tg_block = raw.get("tg") or {}
        tg_enabled = bool(tg_block.get("enabled", raw.get("tg_enabled", False)))
        # tg_authz: same parsing convention as tg_enabled. Default False.
        tg_authz = bool(tg_block.get("authz", raw.get("tg_authz", False)))
        return cls(
            slug=raw["slug"],
            display_name=raw["display_name"],
            repo_path=Path(raw["repo_path"]),
            deploy_branch=raw["deploy_branch"],
            master_branch=raw["master_branch"],
            prod_url=raw.get("prod_url", ""),
            staging_url=raw.get("staging_url", ""),
            dev_url=raw.get("dev_url", ""),
            deploy_targets=tuple(raw["deploy_targets"]),
            tg_chat=str(raw["tg_chat"]),
            repo_master=Path(raw["repo_master"]) if raw.get("repo_master") else None,
            tg_enabled=tg_enabled,
            tg_authz=tg_authz,
        )


@dataclass(frozen=True)
class TgUser:
    """A known Telegram human, keyed on TG ``from.id``.

    Loaded from config/tg_users.toml (NOT auth.toml, which is keyed on web-UI
    login). ``from_id`` is the integer TG user id. ``role`` is one of
    observer/member/director/admin (capability tiers derived in tg_authz.py).
    ``projects`` is the list of project slugs this user may act within; ``["*"]``
    means all projects (admin). ``display`` is a human label for audit/replies.
    """
    from_id: int
    role: str
    projects: tuple[str, ...]
    display: str = ""

    def covers_project(self, slug: str) -> bool:
        """True if this user's project scope includes ``slug`` (``*`` = all)."""
        return "*" in self.projects or slug in self.projects


@dataclass(frozen=True)
class TgAuthzDefaults:
    """Fallback roles for senders with no tg_users.toml record.

    From the ``[defaults]`` block of tg_users.toml. ``group_member_role`` is the
    role granted to an *unknown* sender seen in a project's group chat (scoped to
    that project only). ``dm_unknown_role`` is the role for an unknown sender in
    a DM — default ``denied`` means no capabilities at all.
    """
    group_member_role: str = "observer"
    dm_unknown_role: str = "denied"


@dataclass(frozen=True)
class Config:
    config_dir: Path
    projects: dict[str, Project] = field(default_factory=dict)
    tg_bot_token: str = ""
    # Per-project bot tokens from secrets.toml [telegram_bots] (slug -> token).
    # A project with no entry here falls back to the global tg_bot_token via
    # ``bot_token_for`` — that's how 'computation' keeps using the global bot.
    telegram_bots: dict[str, str] = field(default_factory=dict)
    # Per-user TG identity store from config/tg_users.toml, keyed on int from.id.
    # Loaded like ``telegram_bots``; a missing file tolerates → empty map. Only
    # consulted for projects with ``tg_authz=True``.
    tg_users: dict[int, TgUser] = field(default_factory=dict)
    tg_authz_defaults: "TgAuthzDefaults" = field(default_factory=TgAuthzDefaults)
    tg_auth_age_max: int = 86400
    # Quiet hours during which non-urgent TG sends are dropped. UTC. Loaded
    # from <config_dir>/system_settings.toml; defaults match historical
    # 17→05 UTC sleep window for the Tashkent stakeholder.
    tg_quiet_hours_start_utc: int = 17
    tg_quiet_hours_end_utc: int = 5
    # Personal-account MTProto creds for the tg_user ingest worker. 0/"" =
    # disabled; the worker exits cleanly on startup.
    tg_user_api_id: int = 0
    tg_user_api_hash: str = ""

    @property
    def data_dir(self) -> Path:
        return self.config_dir.parent / "data"

    @property
    def sock_path(self) -> Path:
        return self.data_dir / "_sock" / "worker.sock"

    @property
    def heartbeat_path(self) -> Path:
        return self.data_dir / "_worker" / "heartbeat"

    @property
    def tg_user_dir(self) -> Path:
        return self.data_dir / "_tg"

    @property
    def tg_user_db_path(self) -> Path:
        return self.tg_user_dir / "messages.db"

    @property
    def tg_user_session_path(self) -> Path:
        # Telethon appends ".session"; pass the stem.
        return self.tg_user_dir / "telethon"

    def project_data_dir(self, slug: str) -> Path:
        return self.data_dir / slug

    def bot_token_for(self, slug: str) -> str:
        """Resolve a project's Telegram bot token.

        Per-project token from secrets.toml ``[telegram_bots]`` wins; otherwise
        fall back to the global ``[telegram].bot_token``. 'computation' has no
        per-project entry, so it keeps using the global token (its live bot).
        """
        return self.telegram_bots.get(slug) or self.tg_bot_token

    def enabled_tg_projects(self) -> list[Project]:
        """Projects whose per-project bot the listener should poll.

        A project is polled iff ``tg_enabled`` is True AND it has a resolvable
        bot token. Disabled projects are skipped entirely (never polled).
        """
        return [
            p for p in self.projects.values()
            if p.tg_enabled and self.bot_token_for(p.slug)
        ]

    @classmethod
    def load(cls, config_dir: Path) -> "Config":
        projects_toml = config_dir / "projects.toml"
        if not projects_toml.exists():
            raise FileNotFoundError(f"projects.toml not found: {projects_toml}")
        secrets_toml = config_dir / "secrets.toml"
        if not secrets_toml.exists():
            raise FileNotFoundError(f"secrets.toml not found: {secrets_toml}")
        try:
            raw = tomllib.loads(projects_toml.read_text())
        except tomllib.TOMLDecodeError as e:
            raise ConfigError(f"{projects_toml}: malformed TOML: {e}") from e

        # Validate every project entry, collecting all problems into one
        # message instead of dying on the first bad table.
        projects: dict[str, Project] = {}
        project_errors: list[str] = []
        for slug, p in raw.get("projects", {}).items():
            try:
                projects[slug] = Project.from_toml(p, slug_hint=slug)
            except ConfigError as e:
                project_errors.append(str(e))
        if project_errors:
            raise ConfigError(
                f"{projects_toml}: invalid project config:\n  - "
                + "\n  - ".join(project_errors)
            )

        try:
            sec = tomllib.loads(secrets_toml.read_text())
        except tomllib.TOMLDecodeError as e:
            raise ConfigError(f"{secrets_toml}: malformed TOML: {e}") from e

        # system_settings.toml is optional; defaults match the historical hardcoded
        # values so existing deploys behave identically until the admin writes it.
        quiet_start = 17
        quiet_end = 5
        sys_settings = config_dir / "system_settings.toml"
        if sys_settings.exists():
            sys_raw = tomllib.loads(sys_settings.read_text())
            tg_block = sys_raw.get("tg", {}) or {}
            quiet_start = int(tg_block.get("quiet_hours_start_utc", quiet_start))
            quiet_end = int(tg_block.get("quiet_hours_end_utc", quiet_end))

        tg_user = sec.get("telegram_user", {}) or {}
        telegram_bots = {
            str(k): str(v)
            for k, v in (sec.get("telegram_bots", {}) or {}).items()
            if v
        }

        # tg_users.toml — per-user identity store. Optional: a missing file
        # yields an empty map (no user is known → every sender falls through to
        # the defaults). Keyed on TG from.id (string of int in the file).
        tg_users: dict[int, TgUser] = {}
        defaults = TgAuthzDefaults()
        tg_users_toml = config_dir / "tg_users.toml"
        if tg_users_toml.exists():
            try:
                u_raw = tomllib.loads(tg_users_toml.read_text())
            except tomllib.TOMLDecodeError as e:
                raise ConfigError(f"{tg_users_toml}: malformed TOML: {e}") from e
            d = u_raw.get("defaults", {}) or {}
            defaults = TgAuthzDefaults(
                group_member_role=str(d.get("group_member_role", "observer")),
                dm_unknown_role=str(d.get("dm_unknown_role", "denied")),
            )
            users_block = u_raw.get("users", {}) or {}
            for key, rec in users_block.items():
                try:
                    fid = int(rec.get("from_id", key))
                except (TypeError, ValueError):
                    raise ConfigError(
                        f"{tg_users_toml}: user {key!r} has non-integer from.id"
                    )
                tg_users[fid] = TgUser(
                    from_id=fid,
                    role=str(rec.get("role", "observer")),
                    projects=tuple(rec.get("projects", []) or []),
                    display=str(rec.get("display", "")),
                )

        return cls(
            config_dir=config_dir,
            projects=projects,
            tg_bot_token=sec.get("telegram", {}).get("bot_token", ""),
            telegram_bots=telegram_bots,
            tg_users=tg_users,
            tg_authz_defaults=defaults,
            tg_auth_age_max=int(sec.get("telegram", {}).get("auth_age_max", 86400)),
            tg_quiet_hours_start_utc=quiet_start,
            tg_quiet_hours_end_utc=quiet_end,
            tg_user_api_id=int(tg_user.get("api_id", 0) or 0),
            tg_user_api_hash=str(tg_user.get("api_hash", "") or ""),
        )
