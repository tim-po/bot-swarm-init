"""Personal-account Telegram ingest worker.

Long-lived MTProto (Telethon) client. Subscribes to all incoming messages on
the logged-in user's account and writes them as rows in a SQLite db at
``data/_tg/messages.db``. On startup, catches up history per dialog using a
per-chat cursor so messages received while the worker was down are not lost.

Run with:
    python -m bot_squad_worker.tg_user --config /path/to/config

Requires a prior one-time login via ``tg_user_cli login`` (Telethon session
file at ``data/_tg/telethon.session``).

This module is intentionally separate from ``tg_listener.py`` / ``tg.py``
which speak the Bot API and serve the swarm's own outbound notifications.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import signal
import sqlite3
from pathlib import Path
from typing import Optional

from bot_squad_worker.config import Config


log = logging.getLogger("tg_user")


SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    chat_id      INTEGER NOT NULL,
    msg_id       INTEGER NOT NULL,
    ts           INTEGER NOT NULL,        -- unix seconds, UTC
    chat_title   TEXT,
    sender_id    INTEGER,
    sender_name  TEXT,
    text         TEXT,
    raw_json     TEXT,
    project      TEXT,                    -- nullable; filled by classifier later
    status       TEXT NOT NULL DEFAULT 'new',
    PRIMARY KEY (chat_id, msg_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_ts ON messages (ts DESC);
CREATE INDEX IF NOT EXISTS idx_messages_chat_ts ON messages (chat_id, ts DESC);

CREATE TABLE IF NOT EXISTS chats (
    chat_id      INTEGER PRIMARY KEY,
    title        TEXT,
    kind         TEXT,                    -- 'user' | 'group' | 'channel'
    last_msg_id  INTEGER NOT NULL DEFAULT 0,
    updated_at   INTEGER NOT NULL DEFAULT 0
);
"""


def open_db(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), isolation_level=None)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA)
    return conn


def _chat_kind(entity) -> str:
    cls = type(entity).__name__
    if cls == "User":
        return "user"
    if cls == "Chat":
        return "group"
    if cls == "Channel":
        return "channel" if getattr(entity, "broadcast", False) else "group"
    return "unknown"


def _chat_title(entity) -> str:
    if entity is None:
        return ""
    title = getattr(entity, "title", None)
    if title:
        return str(title)
    first = getattr(entity, "first_name", "") or ""
    last = getattr(entity, "last_name", "") or ""
    full = f"{first} {last}".strip()
    if full:
        return full
    username = getattr(entity, "username", None)
    return f"@{username}" if username else str(getattr(entity, "id", ""))


def _sender_name(sender) -> str:
    if sender is None:
        return ""
    return _chat_title(sender)


def _serialize_message(msg) -> dict:
    """Compact dict-of-primitives snapshot of a Telethon Message for raw_json."""
    return {
        "id": msg.id,
        "date": msg.date.isoformat() if msg.date else None,
        "out": bool(getattr(msg, "out", False)),
        "fwd": bool(getattr(msg, "fwd_from", None)),
        "reply_to_msg_id": getattr(msg, "reply_to_msg_id", None),
        "has_media": bool(getattr(msg, "media", None)),
        "media_type": type(msg.media).__name__ if getattr(msg, "media", None) else None,
    }


async def _record_message(
    conn: sqlite3.Connection,
    client,
    msg,
    chat_entity=None,
) -> None:
    """Insert one message; upsert its chat row. Idempotent on (chat_id, msg_id)."""
    if chat_entity is None:
        try:
            chat_entity = await msg.get_chat()
        except Exception:  # noqa: BLE001 — Telethon raises a wide variety
            chat_entity = None
    try:
        sender = await msg.get_sender()
    except Exception:  # noqa: BLE001
        sender = None

    chat_id = int(msg.chat_id) if msg.chat_id is not None else 0
    ts = int(msg.date.timestamp()) if msg.date else 0
    title = _chat_title(chat_entity)
    sender_id = int(getattr(sender, "id", 0) or 0)
    sender_nm = _sender_name(sender)
    text = msg.message or ""
    raw = json.dumps(_serialize_message(msg))

    conn.execute(
        """
        INSERT OR IGNORE INTO messages
            (chat_id, msg_id, ts, chat_title, sender_id, sender_name, text, raw_json, project, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 'new')
        """,
        (chat_id, int(msg.id), ts, title, sender_id, sender_nm, text, raw),
    )
    conn.execute(
        """
        INSERT INTO chats (chat_id, title, kind, last_msg_id, updated_at)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(chat_id) DO UPDATE SET
            title       = COALESCE(excluded.title, chats.title),
            kind        = COALESCE(excluded.kind, chats.kind),
            last_msg_id = MAX(chats.last_msg_id, excluded.last_msg_id),
            updated_at  = MAX(chats.updated_at, excluded.updated_at)
        """,
        (chat_id, title, _chat_kind(chat_entity), int(msg.id), ts),
    )


async def _catch_up(conn: sqlite3.Connection, client, per_dialog_limit: int = 100) -> int:
    """Pull recent history for every dialog past our stored ``last_msg_id``.

    Bounded by ``per_dialog_limit`` so a never-before-synced account doesn't
    pull millions of messages on first boot. Returns total messages inserted.
    """
    total = 0
    async for dialog in client.iter_dialogs():
        chat_id = int(dialog.id)
        row = conn.execute(
            "SELECT last_msg_id FROM chats WHERE chat_id = ?", (chat_id,)
        ).fetchone()
        last_seen = int(row[0]) if row else 0
        inserted = 0
        async for msg in client.iter_messages(dialog.entity, limit=per_dialog_limit):
            if msg.id <= last_seen:
                break
            await _record_message(conn, client, msg, chat_entity=dialog.entity)
            inserted += 1
        if inserted:
            log.info("catchup: chat=%s (%s) +%d msgs", chat_id, dialog.name, inserted)
            total += inserted
    return total


async def run(cfg: Config) -> int:
    if not cfg.tg_user_api_id or not cfg.tg_user_api_hash:
        log.warning("tg_user disabled: api_id/api_hash empty in secrets.toml [telegram_user]")
        return 0

    from telethon import TelegramClient, events

    cfg.tg_user_dir.mkdir(parents=True, exist_ok=True)
    conn = open_db(cfg.tg_user_db_path)
    log.info("opened db: %s", cfg.tg_user_db_path)

    client = TelegramClient(
        str(cfg.tg_user_session_path),
        cfg.tg_user_api_id,
        cfg.tg_user_api_hash,
    )
    await client.connect()
    if not await client.is_user_authorized():
        log.error(
            "telethon session not authorized — run `python -m bot_squad_worker.tg_user_cli login` first"
        )
        await client.disconnect()
        return 2

    me = await client.get_me()
    log.info("logged in as %s (id=%s)", _sender_name(me), getattr(me, "id", "?"))

    @client.on(events.NewMessage(incoming=True))
    async def _on_new(event) -> None:
        try:
            await _record_message(conn, client, event.message)
        except Exception:  # noqa: BLE001
            log.exception("failed to record incoming message id=%s", event.message.id)

    # Catch up history before going live so missed messages get backfilled.
    try:
        inserted = await _catch_up(conn, client)
        log.info("catchup complete: +%d msgs", inserted)
    except Exception:  # noqa: BLE001
        log.exception("catch-up failed; continuing live")

    stop = asyncio.Event()

    def _signal_stop(*_: object) -> None:
        log.info("shutdown signal received")
        stop.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _signal_stop)
        except NotImplementedError:
            signal.signal(sig, lambda *_: _signal_stop())

    log.info("tg_user listening for new messages")
    # client.run_until_disconnected() blocks until disconnect; we want our
    # own stop-event so we can shut down cleanly on SIGTERM. Race the two.
    disconnected = asyncio.create_task(client.disconnected)
    stopper = asyncio.create_task(stop.wait())
    await asyncio.wait({disconnected, stopper}, return_when=asyncio.FIRST_COMPLETED)

    await client.disconnect()
    conn.close()
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="bot-squad-worker.tg_user")
    parser.add_argument(
        "--config",
        default=os.environ.get("BOT_SQUAD_CONFIG", "/home/www/bot-squad/config"),
        help="path to bot-swarm config dir",
    )
    parser.add_argument("--log-level", default=os.environ.get("LOG_LEVEL", "info"))
    args = parser.parse_args()

    logging.basicConfig(
        level=args.log_level.upper(),
        format="%(asctime)s %(levelname)s %(name)s | %(message)s",
    )

    cfg = Config.load(Path(args.config))
    return asyncio.run(run(cfg))


if __name__ == "__main__":
    raise SystemExit(main())
