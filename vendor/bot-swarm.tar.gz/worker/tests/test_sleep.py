"""Tests for the bot-swarm sleep cycle (transcript extraction + scribe
invocation).

The scribe subprocess is always mocked — these are not full integration
tests against a real ``claude`` binary. End-to-end verification of the
scribe's actual output lives in the manual smoke test, not here.
"""
from __future__ import annotations

import json
import subprocess
import types
from pathlib import Path

import pytest

from bot_squad_worker import sleep as S


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_cfg(tmp_path: Path) -> types.SimpleNamespace:
    """Bare config: data_dir + a single registered project."""
    return types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"swarm-smoke": object()},
    )


def _write_session_md(tmp_path: Path, sid: str, role: str, claude_uuid: str, cwd: str) -> None:
    sess_dir = tmp_path / "data" / "swarm-smoke" / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    (sess_dir / f"{sid}.md").write_text(
        "---\n"
        f"sid: {sid}\n"
        "status: active\n"
        "task_id: ~\n"
        f"role: {role}\n"
        f"cwd: {cwd}\n"
        f"claude_uuid: {claude_uuid}\n"
        "---\n"
    )


def _write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")


# ---------------------------------------------------------------------------
# _extract_transcript
# ---------------------------------------------------------------------------

def test_extract_transcript_picks_up_user_and_assistant(tmp_path):
    jsonl = tmp_path / "x.jsonl"
    _write_jsonl(jsonl, [
        {"type": "system", "message": {"content": "boot noise"}},
        {"type": "user", "message": {"role": "user", "content": "Hi planner."}},
        {"type": "assistant", "message": {"role": "assistant", "content": [
            {"type": "text", "text": "Hello — planner online."},
        ]}},
        {"type": "ai-title", "title": "irrelevant metadata"},
    ])
    transcript, offset = S._extract_transcript(jsonl, 0)
    assert offset == jsonl.stat().st_size
    assert "USER: Hi planner." in transcript
    assert "ASSISTANT: Hello — planner online." in transcript
    # System / metadata kinds dropped.
    assert "boot noise" not in transcript
    assert "irrelevant metadata" not in transcript


def test_extract_transcript_tool_use_summarised(tmp_path):
    jsonl = tmp_path / "x.jsonl"
    _write_jsonl(jsonl, [
        {"type": "assistant", "message": {"role": "assistant", "content": [
            {"type": "tool_use", "name": "Bash",
             "input": {"command": "ls /home\necho hi"}},
            {"type": "text", "text": "Done."},
        ]}},
    ])
    transcript, _ = S._extract_transcript(jsonl, 0)
    assert "[tool Bash] ls /home" in transcript
    assert "Done." in transcript
    # Second line of the multiline command is NOT in the summary.
    assert "echo hi" not in transcript


def test_extract_transcript_resumes_from_offset(tmp_path):
    jsonl = tmp_path / "x.jsonl"
    _write_jsonl(jsonl, [
        {"type": "user", "message": {"role": "user", "content": "first"}},
    ])
    _, first_offset = S._extract_transcript(jsonl, 0)
    # Append more.
    with jsonl.open("a") as f:
        f.write(json.dumps({"type": "user", "message": {"role": "user", "content": "second"}}) + "\n")
    transcript, new_offset = S._extract_transcript(jsonl, first_offset)
    assert "first" not in transcript
    assert "second" in transcript
    assert new_offset == jsonl.stat().st_size


def test_extract_transcript_empty_when_no_new_content(tmp_path):
    jsonl = tmp_path / "x.jsonl"
    _write_jsonl(jsonl, [{"type": "user", "message": {"role": "user", "content": "hi"}}])
    transcript, offset = S._extract_transcript(jsonl, jsonl.stat().st_size)
    assert transcript == ""
    assert offset == jsonl.stat().st_size


def test_extract_transcript_missing_file_returns_empty(tmp_path):
    transcript, offset = S._extract_transcript(tmp_path / "absent.jsonl", 0)
    assert transcript == ""
    assert offset == 0


def test_extract_transcript_skips_malformed_lines(tmp_path):
    jsonl = tmp_path / "x.jsonl"
    jsonl.write_text(
        '{"type": "user", "message": {"role": "user", "content": "ok"}}\n'
        'this is not json\n'
        '{"type": "assistant", "message": {"role": "assistant", "content": [{"type":"text","text":"after"}]}}\n'
    )
    transcript, _ = S._extract_transcript(jsonl, 0)
    assert "USER: ok" in transcript
    assert "ASSISTANT: after" in transcript


# ---------------------------------------------------------------------------
# _resolve_jsonl_path
# ---------------------------------------------------------------------------

def test_resolve_jsonl_prefers_with_leading_dash(tmp_path):
    """Current Claude Code (2.x) keeps the leading dash in the encoded
    project dir; resolver must check that form first.
    """
    user_home = tmp_path / "home"
    uuid = "abc-123"
    cwd = "/home/timpo/swarm-smoke"
    (user_home / ".claude" / "projects" / "-home-timpo-swarm-smoke").mkdir(parents=True)
    target = user_home / ".claude" / "projects" / "-home-timpo-swarm-smoke" / f"{uuid}.jsonl"
    target.write_text("{}\n")
    meta = {"claude_uuid": uuid, "cwd": cwd}
    found = S._resolve_jsonl_path(meta, user_home)
    assert found == target


def test_resolve_jsonl_falls_back_to_old_encoding(tmp_path):
    user_home = tmp_path / "home"
    uuid = "xyz"
    cwd = "/home/timpo/swarm-smoke"
    # Only the lstripped variant exists.
    (user_home / ".claude" / "projects" / "home-timpo-swarm-smoke").mkdir(parents=True)
    target = user_home / ".claude" / "projects" / "home-timpo-swarm-smoke" / f"{uuid}.jsonl"
    target.write_text("{}\n")
    found = S._resolve_jsonl_path({"claude_uuid": uuid, "cwd": cwd}, user_home)
    assert found == target


def test_resolve_jsonl_returns_none_when_missing(tmp_path):
    assert S._resolve_jsonl_path({"claude_uuid": "x", "cwd": "/nope"}, tmp_path) is None
    assert S._resolve_jsonl_path({"cwd": "/x"}, tmp_path) is None
    assert S._resolve_jsonl_path({"claude_uuid": "~", "cwd": "/x"}, tmp_path) is None


# ---------------------------------------------------------------------------
# sleep_expert — full action
# ---------------------------------------------------------------------------

def _mock_scribe_ok(monkeypatch, files_touched=("MEMORY.md", "decisions.md")):
    """Mock subprocess.run to return success and a JSON summary line."""
    calls: list[dict] = []

    def fake_run(args, **kw):
        calls.append({"args": args, "cwd": kw.get("cwd"), "timeout": kw.get("timeout")})
        body = json.dumps({"ok": True, "files_touched": list(files_touched)})
        return subprocess.CompletedProcess(args, 0, body, "")

    monkeypatch.setattr(subprocess, "run", fake_run)
    return calls


def test_sleep_expert_happy_path(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path)
    sid = "S-u-coord-p0"
    uuid = "uuid-1"
    cwd = "/home/u/proj"
    _write_session_md(tmp_path, sid, "coordinator", uuid, cwd)
    user_home = tmp_path / "home"
    jsonl = user_home / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl, [
        {"type": "user", "message": {"role": "user", "content": "let's plan"}},
        {"type": "assistant", "message": {"role": "assistant", "content": [
            {"type": "text", "text": "Planned."},
        ]}},
    ])
    monkeypatch.setattr(S, "_user_home", lambda: user_home)
    calls = _mock_scribe_ok(monkeypatch)

    result = S.sleep_expert(cfg, "swarm-smoke", sid)
    assert result["ok"] is True
    assert result["role"] == "coordinator"
    assert result["compacted_bytes"] > 0
    assert result["mark_before"] == 0
    assert result["mark_after"] == jsonl.stat().st_size

    # Mark file written.
    mark = tmp_path / "data" / "swarm-smoke" / "experts" / "coordinator" / "sleep_mark"
    assert mark.read_text() == str(jsonl.stat().st_size)

    # Scribe invoked with claude -p, in expert dir.
    assert len(calls) == 1
    args = calls[0]["args"]
    assert args[0] == "claude"
    assert "-p" in args
    assert "--dangerously-skip-permissions" in args
    assert calls[0]["cwd"] == str(tmp_path / "data" / "swarm-smoke" / "experts" / "coordinator")
    # Prompt body contains the transcript markers.
    prompt = args[-1]
    assert "let's plan" in prompt
    assert "Planned." in prompt
    assert "SCRIBE" in prompt  # the sleep prompt header


def test_sleep_expert_noop_when_nothing_new(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path)
    sid = "S-u-coord-p0"
    uuid = "uuid-1"
    cwd = "/home/u/proj"
    _write_session_md(tmp_path, sid, "coordinator", uuid, cwd)
    user_home = tmp_path / "home"
    jsonl = user_home / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl, [{"type": "user", "message": {"role": "user", "content": "hi"}}])
    # Mark already at EOF.
    mark = tmp_path / "data" / "swarm-smoke" / "experts" / "coordinator" / "sleep_mark"
    mark.parent.mkdir(parents=True, exist_ok=True)
    mark.write_text(str(jsonl.stat().st_size))
    monkeypatch.setattr(S, "_user_home", lambda: user_home)

    def must_not_be_called(*a, **kw):
        raise AssertionError("scribe must not run when transcript is empty")

    monkeypatch.setattr(subprocess, "run", must_not_be_called)

    result = S.sleep_expert(cfg, "swarm-smoke", sid)
    assert result["compacted_bytes"] == 0
    assert result.get("note") == "no new transcript since last sleep"


def test_sleep_expert_rejects_session_without_role(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    sid = "S-u-leg-p0"
    sess_dir = tmp_path / "data" / "swarm-smoke" / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    (sess_dir / f"{sid}.md").write_text(
        "---\nsid: S-u-leg-p0\nrole: ~\ncwd: /x\nclaude_uuid: u\n---\n"
    )
    with pytest.raises(ActionError, match="has no role"):
        S.sleep_expert(cfg, "swarm-smoke", sid)


def test_sleep_expert_rejects_unknown_slug(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="unknown slug"):
        S.sleep_expert(cfg, "no-such-slug", "S-x")


def test_sleep_expert_rejects_when_jsonl_missing(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    sid = "S-u-coord-p0"
    _write_session_md(tmp_path, sid, "coordinator", "uuid-1", "/home/u/proj")
    monkeypatch.setattr(S, "_user_home", lambda: tmp_path / "home")
    # No jsonl created.
    with pytest.raises(ActionError, match="could not resolve jsonl"):
        S.sleep_expert(cfg, "swarm-smoke", sid)


def test_sleep_expert_raises_on_scribe_nonzero(tmp_path, monkeypatch):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    sid = "S-u-coord-p0"
    uuid = "uuid-1"
    cwd = "/home/u/proj"
    _write_session_md(tmp_path, sid, "coordinator", uuid, cwd)
    user_home = tmp_path / "home"
    jsonl = user_home / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    _write_jsonl(jsonl, [{"type": "user", "message": {"role": "user", "content": "hi"}}])
    monkeypatch.setattr(S, "_user_home", lambda: user_home)

    def fake_run(args, **kw):
        return subprocess.CompletedProcess(args, 2, "", "boom: api error")

    monkeypatch.setattr(subprocess, "run", fake_run)
    with pytest.raises(ActionError, match="scribe exited with code 2"):
        S.sleep_expert(cfg, "swarm-smoke", sid)
    # Mark must NOT be advanced on scribe failure.
    mark = tmp_path / "data" / "swarm-smoke" / "experts" / "coordinator" / "sleep_mark"
    assert not mark.exists()


def test_sleep_expert_tail_clips_huge_transcripts(tmp_path, monkeypatch):
    """A transcript bigger than _MAX_TRANSCRIPT_BYTES is tail-clipped so
    the scribe call doesn't get a runaway prompt. The mark still advances
    to the real EOF so the next sleep doesn't reprocess the same bytes."""
    cfg = _make_cfg(tmp_path)
    sid = "S-u-coord-p0"
    uuid = "uuid-1"
    cwd = "/home/u/proj"
    _write_session_md(tmp_path, sid, "coordinator", uuid, cwd)
    user_home = tmp_path / "home"
    jsonl = user_home / ".claude" / "projects" / "-home-u-proj" / f"{uuid}.jsonl"
    # Many small user lines until well over the budget.
    big_content = "x" * 1000
    records = [
        {"type": "user", "message": {"role": "user", "content": f"early-{i} {big_content}"}}
        for i in range(50)
    ] + [
        {"type": "user", "message": {"role": "user", "content": "LATEST_MARKER"}},
    ]
    _write_jsonl(jsonl, records)
    monkeypatch.setattr(S, "_user_home", lambda: user_home)
    monkeypatch.setattr(S, "_MAX_TRANSCRIPT_BYTES", 5_000)
    calls = _mock_scribe_ok(monkeypatch)

    S.sleep_expert(cfg, "swarm-smoke", sid)
    prompt = calls[0]["args"][-1]
    assert "LATEST_MARKER" in prompt  # tail preserved
    assert "early-0" not in prompt    # head clipped
    # Mark advanced to true EOF, not the clipped boundary.
    mark = tmp_path / "data" / "swarm-smoke" / "experts" / "coordinator" / "sleep_mark"
    assert int(mark.read_text()) == jsonl.stat().st_size
