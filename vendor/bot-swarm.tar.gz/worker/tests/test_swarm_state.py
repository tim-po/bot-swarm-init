"""Tests for the read-only swarm-state surface."""
from __future__ import annotations

import types
from pathlib import Path

import pytest

from bot_squad_worker import swarm_state as ST


def _make_cfg(tmp_path: Path) -> types.SimpleNamespace:
    return types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"stash": object()},
    )


def _write_initiative(tmp_path: Path, id: str, status: str = "proposed",
                      title: str = "Stash MVP", related: list[str] | None = None,
                      body: str = "## Goal\nWhatever.\n") -> Path:
    d = tmp_path / "data" / "stash" / "initiatives"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{id}-stash-mvp.md"
    related_str = f"[{', '.join(related)}]" if related else "[]"
    p.write_text(
        "---\n"
        f"id: {id}\n"
        f"title: {title}\n"
        f"status: {status}\n"
        "created_at: 2026-05-18\n"
        f"related_tasks: {related_str}\n"
        "owner: coordinator\n"
        "---\n"
        f"{body}"
    )
    return p


def _write_task(tmp_path: Path, id: str, status: str = "ready",
                role: str = "backend-expert", initiative: str = "I-0001",
                deps: list[str] | None = None,
                title: str = "Backend skeleton") -> Path:
    d = tmp_path / "data" / "stash" / "backlog"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"{id}-stash-{role}.md"
    deps_str = f"[{', '.join(deps)}]" if deps else "[]"
    p.write_text(
        "---\n"
        f"id: {id}\n"
        f"title: {title}\n"
        f"initiative_id: {initiative}\n"
        f"assigned_role: {role}\n"
        f"status: {status}\n"
        f"depends_on: {deps_str}\n"
        "created_at: 2026-05-18\n"
        "---\n"
        "## Goal\nBody.\n"
    )
    return p


# ---------------------------------------------------------------------------
# Frontmatter parsing
# ---------------------------------------------------------------------------

def test_parse_frontmatter_basic():
    meta, body = ST._parse_frontmatter(
        "---\nid: I-0001\nstatus: active\nrelated_tasks: [T-1, T-2]\n---\n\nbody here\n"
    )
    assert meta["id"] == "I-0001"
    assert meta["status"] == "active"
    assert meta["related_tasks"] == ["T-1", "T-2"]
    assert "body here" in body


def test_parse_frontmatter_tilde_is_none():
    meta, _ = ST._parse_frontmatter("---\ndescription: ~\n---\n")
    assert meta["description"] is None


def test_parse_frontmatter_missing_returns_empty():
    meta, body = ST._parse_frontmatter("no frontmatter here\n")
    assert meta == {}
    assert body == "no frontmatter here\n"


# ---------------------------------------------------------------------------
# list_initiatives / read_initiative
# ---------------------------------------------------------------------------

def test_list_initiatives_returns_structured_records(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_initiative(tmp_path, "I-0001", status="active",
                      related=["T-0001", "T-0002"])
    _write_initiative(tmp_path, "I-0002", status="proposed")
    out = ST.list_initiatives(cfg, "stash")
    assert len(out) == 2
    by_id = {i["id"]: i for i in out}
    assert by_id["I-0001"]["status"] == "active"
    assert by_id["I-0001"]["related_tasks"] == ["T-0001", "T-0002"]
    assert by_id["I-0002"]["status"] == "proposed"


def test_list_initiatives_empty_when_dir_missing(tmp_path):
    cfg = _make_cfg(tmp_path)
    assert ST.list_initiatives(cfg, "stash") == []


def test_list_initiatives_rejects_unknown_slug(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="unknown slug"):
        ST.list_initiatives(cfg, "no-such-slug")


def test_read_initiative_returns_body_and_frontmatter(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_initiative(tmp_path, "I-0001", body="## Goal\nBuild it.\n")
    rec = ST.read_initiative(cfg, "stash", "I-0001")
    assert rec["frontmatter"]["status"] == "proposed"
    assert "Build it." in rec["body"]


def test_read_initiative_not_found_raises(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="not found"):
        ST.read_initiative(cfg, "stash", "I-9999")


# ---------------------------------------------------------------------------
# list_tasks / read_task
# ---------------------------------------------------------------------------

def test_list_tasks_groups_role_and_status(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_task(tmp_path, "T-0001", role="backend-expert", status="ready")
    _write_task(tmp_path, "T-0002", role="backend-expert", status="in_progress",
                deps=["T-0001"])
    _write_task(tmp_path, "T-0003", role="frontend-expert", status="ready")
    out = ST.list_tasks(cfg, "stash")
    by_id = {t["id"]: t for t in out}
    assert by_id["T-0002"]["depends_on"] == ["T-0001"]
    assert by_id["T-0002"]["assigned_role"] == "backend-expert"
    assert by_id["T-0003"]["assigned_role"] == "frontend-expert"
    # Sorted by filename → T-0001 first.
    assert out[0]["id"] == "T-0001"


def test_read_task_returns_body(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_task(tmp_path, "T-0001")
    rec = ST.read_task(cfg, "stash", "T-0001")
    assert rec["frontmatter"]["assigned_role"] == "backend-expert"
    assert "## Goal" in rec["body"]


def test_read_task_not_found_raises(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="not found"):
        ST.read_task(cfg, "stash", "T-9999")


# ---------------------------------------------------------------------------
# list_experts
# ---------------------------------------------------------------------------

def test_list_experts_reports_layout(tmp_path):
    cfg = _make_cfg(tmp_path)
    base = tmp_path / "data" / "stash" / "experts"
    (base / "coordinator" / "memory").mkdir(parents=True)
    (base / "coordinator" / "identity.md").write_text("# coordinator")
    (base / "coordinator" / "memory" / "MEMORY.md").write_text("idx")
    (base / "coordinator" / "memory" / "project-scope.md").write_text("scope")
    (base / "coordinator" / "sleep_mark").write_text("12345")
    (base / "planner" / "memory").mkdir(parents=True)
    (base / "planner" / "identity.md").write_text("# planner")

    out = ST.list_experts(cfg, "stash")
    by_role = {e["role"]: e for e in out}
    assert by_role["coordinator"]["has_identity"] is True
    assert sorted(by_role["coordinator"]["memory_files"]) == ["MEMORY.md", "project-scope.md"]
    assert by_role["coordinator"]["sleep_mark"] == 12345
    assert by_role["coordinator"]["archived"] is False
    assert by_role["planner"]["sleep_mark"] is None


def test_list_experts_surfaces_archived(tmp_path):
    cfg = _make_cfg(tmp_path)
    base = tmp_path / "data" / "stash" / "experts"
    (base / "_archive" / "old-monolith-expert" / "memory").mkdir(parents=True)
    (base / "_archive" / "old-monolith-expert" / "identity.md").write_text("retired")

    out = ST.list_experts(cfg, "stash")
    by_role = {e["role"]: e for e in out}
    assert by_role["old-monolith-expert"]["archived"] is True
    assert by_role["old-monolith-expert"]["has_identity"] is True


def test_list_experts_empty_when_missing(tmp_path):
    cfg = _make_cfg(tmp_path)
    assert ST.list_experts(cfg, "stash") == []


# ---------------------------------------------------------------------------
# read_expert_memory
# ---------------------------------------------------------------------------

def test_read_expert_memory_returns_content(tmp_path):
    cfg = _make_cfg(tmp_path)
    mem = tmp_path / "data" / "stash" / "experts" / "coordinator" / "memory"
    mem.mkdir(parents=True)
    (mem / "roster.md").write_text("# roster\nbody here")
    rec = ST.read_expert_memory(cfg, "stash", "coordinator", "roster.md")
    assert rec["filename"] == "roster.md"
    assert "body here" in rec["content"]
    assert rec["role"] == "coordinator"


def test_read_expert_memory_not_found_raises(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    (tmp_path / "data" / "stash" / "experts" / "coordinator" / "memory").mkdir(parents=True)
    with pytest.raises(ActionError, match="not found"):
        ST.read_expert_memory(cfg, "stash", "coordinator", "missing.md")


def test_read_expert_memory_rejects_traversal(tmp_path):
    """Filename must be a single segment ending .md — no slashes, no ..,
    so even a malicious ``../../etc/passwd`` is blocked before touching
    the filesystem.
    """
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="invalid filename"):
        ST.read_expert_memory(cfg, "stash", "coordinator", "../../etc/passwd")
    with pytest.raises(ActionError, match="invalid filename"):
        ST.read_expert_memory(cfg, "stash", "coordinator", "foo/bar.md")
    with pytest.raises(ActionError, match="invalid filename"):
        ST.read_expert_memory(cfg, "stash", "coordinator", "no-extension")


def test_read_expert_memory_rejects_unknown_slug(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _make_cfg(tmp_path)
    with pytest.raises(ActionError, match="unknown slug"):
        ST.read_expert_memory(cfg, "nope", "coordinator", "x.md")
