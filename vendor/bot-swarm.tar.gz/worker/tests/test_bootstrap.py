"""Tests for the project-repo bootstrap action."""
from __future__ import annotations

import json
import types
from pathlib import Path

import pytest

from bot_squad_worker import bootstrap as B


def _cfg(tmp_path: Path, repo_path: Path) -> types.SimpleNamespace:
    project = types.SimpleNamespace(repo_path=repo_path)
    return types.SimpleNamespace(
        data_dir=tmp_path / "data",
        projects={"stash": project},
    )


def test_bootstrap_writes_settings_json(tmp_path):
    repo = tmp_path / "repo"
    cfg = _cfg(tmp_path, repo)
    result = B.bootstrap_project_repo(cfg, "stash")
    assert result["ok"] is True
    assert result["action"] == "written"
    settings_path = repo / ".claude" / "settings.json"
    assert settings_path.is_file()

    payload = json.loads(settings_path.read_text())
    # Hook commands point at the install root's scripts/hooks/.
    install_root = tmp_path
    session_start = payload["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    assert session_start == str(install_root / "scripts" / "hooks" / "session_start.sh")
    # Permissions list is included so the spawned pane doesn't pause for tool prompts.
    assert "Bash" in payload["permissions"]["allow"]


def test_bootstrap_merges_into_existing_settings(tmp_path):
    """Pre-existing settings.json must keep its non-swarm keys, get
    swarm hooks merged in, and produce a one-time backup."""
    repo = tmp_path / "repo"
    cfg = _cfg(tmp_path, repo)
    (repo / ".claude").mkdir(parents=True)
    existing = {
        "mcpServers": {"some_server": {"command": "/bin/x"}},
        "hooks": {"SessionStart": [{"hooks": [{"type": "command", "command": "/old/path.sh"}]}]},
        "permissions": {"allow": ["Custom"]},
        "model": "user-pref",
    }
    (repo / ".claude" / "settings.json").write_text(json.dumps(existing))

    result = B.bootstrap_project_repo(cfg, "stash")
    assert result["action"] == "merged"

    payload = json.loads((repo / ".claude" / "settings.json").read_text())
    # Swarm hooks overwrote the old path.
    install_root = tmp_path
    new_cmd = payload["hooks"]["SessionStart"][0]["hooks"][0]["command"]
    assert new_cmd == str(install_root / "scripts" / "hooks" / "session_start.sh")
    # Non-swarm keys preserved.
    assert payload["mcpServers"] == {"some_server": {"command": "/bin/x"}}
    assert payload["model"] == "user-pref"
    # Existing permission entry preserved + our entries added.
    assert "Custom" in payload["permissions"]["allow"]
    assert "Bash" in payload["permissions"]["allow"]
    # Backup of the pre-swarm content stored once.
    bak = repo / ".claude" / "settings.json.pre-swarm.bak"
    assert bak.is_file()
    assert json.loads(bak.read_text()) == existing


def test_bootstrap_re_run_is_unchanged(tmp_path):
    """Running bootstrap twice in a row on the same install is a no-op."""
    repo = tmp_path / "repo"
    cfg = _cfg(tmp_path, repo)
    first = B.bootstrap_project_repo(cfg, "stash")
    assert first["action"] == "written"
    second = B.bootstrap_project_repo(cfg, "stash")
    assert second["action"] == "unchanged"


def test_bootstrap_recovers_from_corrupt_json(tmp_path):
    """Unparseable settings.json gets backed up and replaced with fresh."""
    repo = tmp_path / "repo"
    cfg = _cfg(tmp_path, repo)
    (repo / ".claude").mkdir(parents=True)
    (repo / ".claude" / "settings.json").write_text("this isn't json {{{")
    result = B.bootstrap_project_repo(cfg, "stash")
    assert result["action"] == "written"
    bak = repo / ".claude" / "settings.json.pre-swarm.bak"
    assert bak.is_file()
    assert bak.read_text() == "this isn't json {{{"


def test_bootstrap_creates_missing_repo_dir(tmp_path):
    """The repo path may not exist yet — bootstrap creates it so a
    fresh project can be configured before any code is in place."""
    repo = tmp_path / "fresh-repo"
    cfg = _cfg(tmp_path, repo)
    assert not repo.exists()
    B.bootstrap_project_repo(cfg, "stash")
    assert repo.is_dir()
    assert (repo / ".claude" / "settings.json").is_file()


def test_bootstrap_rejects_unknown_slug(tmp_path):
    from bot_squad_worker.actions import ActionError
    cfg = _cfg(tmp_path, tmp_path / "x")
    with pytest.raises(ActionError, match="unknown slug"):
        B.bootstrap_project_repo(cfg, "no-such-slug")
