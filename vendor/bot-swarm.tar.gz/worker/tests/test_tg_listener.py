"""Tests for worker.tg_listener — all network + subprocess mocked."""
from __future__ import annotations

import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

import bot_squad_worker.tg_listener as TL


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cfg(tmp_path: Path, *, bot_token: str = "TESTBOT:TOKEN", tg_chat: str = "12345",
              telegram_bots: dict | None = None, tg_enabled: bool = True,
              tg_authz: bool = False, tg_users: dict | None = None,
              dm_unknown_role: str = "denied", group_member_role: str = "observer"):
    """Build a minimal config-like namespace for tg_listener tests."""
    data_dir = tmp_path / "data"
    (data_dir / "_worker").mkdir(parents=True)
    proj = types.SimpleNamespace(
        slug="test-project",
        display_name="Test Project",
        repo_path=Path("/tmp/test-repo"),
        tg_chat=tg_chat,
        tg_enabled=tg_enabled,
        tg_authz=tg_authz,
    )
    telegram_bots = telegram_bots or {}

    def bot_token_for(slug: str) -> str:
        return telegram_bots.get(slug) or bot_token

    def enabled_tg_projects():
        return [p for p in [proj] if p.tg_enabled and bot_token_for(p.slug)]

    return types.SimpleNamespace(
        tg_bot_token=bot_token,
        telegram_bots=telegram_bots,
        data_dir=data_dir,
        projects={"test-project": proj},
        bot_token_for=bot_token_for,
        enabled_tg_projects=enabled_tg_projects,
        tg_users=tg_users or {},
        tg_authz_defaults=types.SimpleNamespace(
            dm_unknown_role=dm_unknown_role,
            group_member_role=group_member_role,
        ),
    )


def _tg_user(from_id, role, projects, display=""):
    return types.SimpleNamespace(
        from_id=from_id, role=role, projects=tuple(projects), display=display,
    )


def _reply_message(sid: str, reply_text: str, chat_id: int = 12345) -> dict:
    """Build a fake TG message that is a reply to a worker notification."""
    return {
        "message_id": 200,
        "chat": {"id": chat_id, "type": "private"},
        "text": reply_text,
        "reply_to_message": {
            "message_id": 100,
            "text": f"[{sid}] needs your input — waiting",
        },
    }


def _slash_message(text: str, chat_id: int = 12345) -> dict:
    """Build a fake TG message with a slash command."""
    return {
        "message_id": 201,
        "chat": {"id": chat_id, "type": "private"},
        "text": text,
    }


# ---------------------------------------------------------------------------
# extract_reply_target
# ---------------------------------------------------------------------------


def test_extract_reply_target_well_formed():
    msg = _reply_message("S-alice-spec5-p3", "yes go ahead")
    result = TL.extract_reply_target(msg)
    assert result == ("S-alice-spec5-p3", "yes go ahead")


def test_extract_reply_target_no_reply():
    msg = {"text": "hello", "chat": {"id": 1}}
    assert TL.extract_reply_target(msg) is None


def test_extract_reply_target_reply_without_sid():
    msg = {
        "text": "hi",
        "reply_to_message": {"text": "some random message without SID"},
    }
    assert TL.extract_reply_target(msg) is None


def test_extract_reply_target_sid_not_at_start():
    # SID_RE uses match (from start), so mid-string SID should NOT match
    msg = {
        "text": "ok",
        "reply_to_message": {"text": "prefix text [S-alice-spec5-p3] in middle"},
    }
    # The regex is anchored at start via .match(), so this should return None
    assert TL.extract_reply_target(msg) is None


def test_extract_reply_target_strips_text_whitespace():
    msg = _reply_message("S-alice-spec5-p3", "  yes  ")
    sid, text = TL.extract_reply_target(msg)
    assert text == "yes"


# ---------------------------------------------------------------------------
# extract_slash_command
# ---------------------------------------------------------------------------


def test_extract_slash_command_sessions():
    msg = _slash_message("/sessions")
    assert TL.extract_slash_command(msg) == ("sessions", "")


def test_extract_slash_command_say():
    msg = _slash_message("/say S-alice-spec5-p3 hello world")
    assert TL.extract_slash_command(msg) == ("say", "S-alice-spec5-p3 hello world")


def test_extract_slash_command_say_with_botname():
    msg = _slash_message("/say@watchbot S-alice-spec5-p3 hi")
    assert TL.extract_slash_command(msg) == ("say", "S-alice-spec5-p3 hi")


def test_extract_slash_command_help():
    msg = _slash_message("/help")
    assert TL.extract_slash_command(msg) == ("help", "")


def test_extract_slash_command_unknown_returns_none():
    msg = _slash_message("/garbage something")
    assert TL.extract_slash_command(msg) is None


def test_extract_slash_command_no_slash():
    msg = _slash_message("just normal text")
    assert TL.extract_slash_command(msg) is None


# ---------------------------------------------------------------------------
# handle_update
# ---------------------------------------------------------------------------


def test_handle_update_skips_non_message(tmp_path):
    cfg = _make_cfg(tmp_path)
    update = {"update_id": 1, "edited_message": {"text": "nope"}}
    result = TL.handle_update(cfg, update)
    assert result["action"] == "skip"
    assert result["reason"] == "no message"


def test_handle_update_skips_non_allowlisted_group(tmp_path):
    """A group chat not in the bot's project allowlist is skipped."""
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    proj = cfg.projects["test-project"]
    update = {
        "update_id": 2,
        "message": {"chat": {"id": 99999, "type": "supergroup"}, "text": "hi"},
    }
    result = TL.handle_update(cfg, update, proj=proj)
    assert result["action"] == "skip"
    assert "not allowlisted" in result["reason"]


def test_handle_update_dm_always_answered(tmp_path, monkeypatch):
    """A DM (private chat) is answered even if its id is not in tg_chat."""
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    proj = cfg.projects["test-project"]
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread", lambda *a, **k: types.SimpleNamespace(start=lambda: None))
    update = {
        "update_id": 22,
        "message": {"chat": {"id": 200974761, "type": "private"},
                    "from": {"first_name": "Tim"}, "text": "hello"},
    }
    result = TL.handle_update(cfg, update, proj=proj)
    assert result["action"] == "chat"


def test_handle_update_dispatches_reply_to_inject(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    msg = _reply_message("S-alice-spec5-p3", "go ahead", chat_id=12345)
    update = {"update_id": 3, "message": msg}

    import bot_squad_worker.actions as A
    monkeypatch.setattr(A, "dispatch", lambda name, params: {"ok": True, "pane_id": "%3", "lines_sent": 1})

    result = TL.handle_update(cfg, update)
    assert result["ok"] is True
    assert result["action"] == "inject"
    assert result["sid"] == "S-alice-spec5-p3"


def test_handle_update_dispatches_sessions_slash(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    msg = _slash_message("/sessions", chat_id=12345)
    update = {"update_id": 4, "message": msg}

    import bot_squad_worker.sessions as S
    monkeypatch.setattr(S, "list_sessions", lambda _cfg, _slug: [
        {"sid": "S-alice-spec5-p3", "window": "spec5", "status": "active"}
    ])

    # Mock _notify to avoid real HTTP
    monkeypatch.setattr(TL, "_notify", lambda cfg, token, chat_id, text: None)

    result = TL.handle_update(cfg, update)
    assert result["ok"] is True
    assert result["action"] == "sessions"
    assert result["count"] == 1


def test_handle_update_dispatches_say_slash(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    msg = _slash_message("/say S-alice-spec5-p3 hello", chat_id=12345)
    update = {"update_id": 5, "message": msg}

    import bot_squad_worker.actions as A
    dispatch_calls = []
    monkeypatch.setattr(A, "dispatch", lambda name, params: dispatch_calls.append((name, params)) or {"ok": True, "pane_id": "%3", "lines_sent": 1})

    result = TL.handle_update(cfg, update)
    assert result["ok"] is True
    assert result["action"] == "say"
    assert dispatch_calls[0] == ("inject_input", {"sid": "S-alice-spec5-p3", "text": "hello"})


def test_handle_update_inject_failed_notifies(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    msg = _reply_message("S-alice-spec5-p3", "text", chat_id=12345)
    update = {"update_id": 6, "message": msg}

    import bot_squad_worker.actions as A
    monkeypatch.setattr(A, "dispatch", MagicMock(side_effect=A.ActionError("no pane")))

    notify_calls = []
    monkeypatch.setattr(TL, "_notify", lambda cfg, token, chat_id, text: notify_calls.append(text))

    result = TL.handle_update(cfg, update)
    assert result["ok"] is False
    assert result["action"] == "inject_failed"
    assert len(notify_calls) == 1
    assert "not active" in notify_calls[0]


def test_handle_update_answers_addressed_group_message(tmp_path, monkeypatch):
    """A plain message in an allowlisted group is routed to the brain.

    Privacy mode means getUpdates only delivers @mentions/replies/commands in
    groups, so any plain group message we actually receive is addressed to us
    and should be answered (no extra mention-parsing needed)."""
    cfg = _make_cfg(tmp_path, tg_chat="12345")
    proj = cfg.projects["test-project"]
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread", lambda *a, **k: types.SimpleNamespace(start=lambda: None))
    msg = {"chat": {"id": 12345, "type": "supergroup"},
           "from": {"first_name": "Ed"}, "text": "@bot just chatting"}
    update = {"update_id": 7, "message": msg}
    result = TL.handle_update(cfg, update, proj=proj)
    assert result["action"] == "chat"


# ---------------------------------------------------------------------------
# tick
# ---------------------------------------------------------------------------


def test_tick_reads_polls_and_writes(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path)
    # Seed a last_update_id
    TL._write_last_update_id(cfg, 99)

    fake_updates = [
        {"update_id": 100, "message": {"chat": {"id": 99999}, "text": "ignored"}},
        {"update_id": 101, "message": {"chat": {"id": 99999}, "text": "also ignored"}},
    ]
    monkeypatch.setattr(TL, "poll_updates", lambda cfg, last_id, timeout=25, token=None: fake_updates)
    monkeypatch.setattr(TL, "handle_update", lambda cfg, upd, proj=None: {"ok": True, "action": "skip"})

    result = TL.tick(cfg)
    assert result["polled"] == 2
    assert result["max_update_id"] == 101
    assert TL._read_last_update_id(cfg) == 101


def test_tick_empty_result(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path)
    TL._write_last_update_id(cfg, 50)
    monkeypatch.setattr(TL, "poll_updates", lambda cfg, last_id, timeout=25, token=None: [])

    result = TL.tick(cfg)
    assert result["polled"] == 0
    assert result["max_update_id"] == 50
    # No new ID written
    assert TL._read_last_update_id(cfg) == 50


def test_tick_network_error_handled(tmp_path, monkeypatch):
    """poll_updates returns [] on network error — tick should complete cleanly."""
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(TL, "poll_updates", lambda cfg, last_id, timeout=25, token=None: [])

    result = TL.tick(cfg)
    assert result["ok"] is True
    assert result["polled"] == 0


def test_tick_missing_token(tmp_path, monkeypatch):
    """No bot token — poll_updates returns [] immediately, tick is a no-op."""
    cfg = _make_cfg(tmp_path, bot_token="")
    # poll_updates should return [] because no token
    result = TL.tick(cfg)
    assert result["ok"] is True
    assert result["polled"] == 0


def test_tick_bad_update_does_not_poison_offset(tmp_path, monkeypatch):
    """One update that raises in handle_update should not prevent writing max_id."""
    cfg = _make_cfg(tmp_path)
    TL._write_last_update_id(cfg, 0)

    fake_updates = [
        {"update_id": 200},
        {"update_id": 201},
    ]
    call_count = [0]

    def bad_handle(cfg, upd, proj=None):
        call_count[0] += 1
        if upd["update_id"] == 200:
            raise RuntimeError("simulated crash")
        return {"ok": True, "action": "skip"}

    monkeypatch.setattr(TL, "poll_updates", lambda cfg, last_id, timeout=25, token=None: fake_updates)
    monkeypatch.setattr(TL, "handle_update", bad_handle)

    result = TL.tick(cfg)
    # handled only 1 (200 crashed, 201 succeeded)
    assert result["handled"] == 1
    # max_id should still be 201
    assert result["max_update_id"] == 201
    assert TL._read_last_update_id(cfg) == 201


# ---------------------------------------------------------------------------
# Per-project: brain cwd/prompt/session-id + token routing + offsets
# ---------------------------------------------------------------------------


def test_chat_session_id_keyed_by_slug_and_chat():
    """Same chat id under different projects yields different session ids;
    'computation' keeps the legacy single-arg derivation for continuity."""
    import hashlib
    legacy = TL._CHAT_SESSION_NS + hashlib.sha1("12345".encode()).hexdigest()[:2]
    assert TL._chat_session_id("computation", "12345") == legacy
    a = TL._chat_session_id("swarmdev", "12345")
    b = TL._chat_session_id("other", "12345")
    assert a != b
    assert a != legacy


def test_chat_system_prompt_computation_unchanged():
    proj = types.SimpleNamespace(slug="computation", display_name="computation")
    assert TL._chat_system_prompt(proj) == TL._COMPUTATION_PROMPT


def test_chat_system_prompt_generic_uses_project_name():
    proj = types.SimpleNamespace(slug="swarmdev", display_name="swarmdev")
    p = TL._chat_system_prompt(proj)
    assert "swarmdev" in p
    assert p != TL._COMPUTATION_PROMPT
    # Safety posture preserved.
    assert "1-6 sentences" in p
    assert "unless the user explicitly asks" in p


def test_handle_chat_derives_cwd_and_token_from_project(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, telegram_bots={"test-project": "PROJ:TOKEN"})
    proj = cfg.projects["test-project"]
    captured = {}

    def fake_thread(target=None, args=(), daemon=None):
        captured["args"] = args
        return types.SimpleNamespace(start=lambda: None)

    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread", fake_thread)

    msg = {"chat": {"id": 200974761, "type": "private"},
           "from": {"first_name": "Tim"}, "text": "hi"}
    result = TL._handle_chat(cfg, proj, "200974761", msg)
    assert result["action"] == "chat"
    # _run_coordinator_turn(cfg, token, chat_id, cwd, sid, prompt, system_prompt)
    _cfg, token, chat_id, cwd, sid, prompt, sysprompt = captured["args"]
    assert token == "PROJ:TOKEN"           # per-project token resolved
    # cwd is an ISOLATED per-slug brain dir, NOT the repo_path — running the
    # tool-less brain in the real repo dir collided with a human's interactive
    # `claude` session store there (2026-06-26 "Session ID already in use").
    assert cwd == TL._brain_cwd("test-project")
    assert cwd != "/tmp/test-repo"
    assert "_brain_cwd" in cwd
    assert "Test Project" in sysprompt      # project-derived prompt


def test_last_update_id_path_legacy_for_global_token(tmp_path):
    """Project on the global token keeps the legacy offset filename."""
    cfg = _make_cfg(tmp_path)  # no telegram_bots -> global token
    p = TL._last_update_id_path(cfg, "test-project")
    assert p.name == "tg_last_update_id"


def test_last_update_id_path_per_slug_for_own_token(tmp_path):
    cfg = _make_cfg(tmp_path, telegram_bots={"test-project": "PROJ:TOKEN"})
    p = TL._last_update_id_path(cfg, "test-project")
    assert p.name == "tg_last_update_id-test-project"


def test_disabled_project_not_polled(tmp_path, monkeypatch):
    """tg_enabled=False -> tick never polls that project's bot."""
    cfg = _make_cfg(tmp_path, tg_enabled=False)
    calls = []
    monkeypatch.setattr(TL, "poll_updates",
                        lambda *a, **k: calls.append(a) or [])
    result = TL.tick(cfg)
    assert calls == []
    assert result["polled"] == 0
    assert result["projects"] == []


def test_tick_polls_per_project_token_and_offset(tmp_path, monkeypatch):
    """Enabled project with its own token is polled with that token + offset."""
    cfg = _make_cfg(tmp_path, telegram_bots={"test-project": "PROJ:TOKEN"})
    TL._write_last_update_id(cfg, 41, "test-project")
    seen = {}

    def fake_poll(cfg, last_id, timeout=25, token=None):
        seen["token"] = token
        seen["last_id"] = last_id
        return [{"update_id": 42, "message": {"chat": {"id": 1}}}]

    monkeypatch.setattr(TL, "poll_updates", fake_poll)
    monkeypatch.setattr(TL, "handle_update", lambda cfg, upd, proj=None: {"ok": True})
    result = TL.tick(cfg)
    assert seen["token"] == "PROJ:TOKEN"
    assert seen["last_id"] == 41
    assert result["max_update_id"] == 42
    # Offset persisted to the per-slug file.
    assert TL._read_last_update_id(cfg, "test-project") == 42
    assert (tmp_path / "data" / "_worker" / "tg_last_update_id-test-project").exists()


# ---------------------------------------------------------------------------
# Per-user authz (tg_authz=True). CRUCIAL: prove tg_authz=False is untouched.
# ---------------------------------------------------------------------------

_TIM = 200974761


def _slash_from(text, from_id, chat_id=None, chat_type="private"):
    """Slash message carrying a from.id envelope (and matching DM chat by id)."""
    chat_id = chat_id if chat_id is not None else from_id
    return {
        "message_id": 300,
        "chat": {"id": chat_id, "type": chat_type},
        "from": {"id": from_id, "first_name": "X"},
        "text": text,
    }


def test_authz_off_skips_all_new_logic(tmp_path, monkeypatch):
    """tg_authz=False (computation's posture): NO identity resolution, NO authz,
    NO rate limit — _handle_slash takes the legacy path verbatim.

    We prove it two ways: (a) tg_authz.resolve_identity / authorize are never
    called even for a /say from an unknown stranger, and (b) the legacy /say
    still dispatches inject_input exactly as before."""
    cfg = _make_cfg(tmp_path, tg_authz=False, tg_chat="12345")
    proj = cfg.projects["test-project"]

    import bot_squad_worker.tg_authz as Z
    monkeypatch.setattr(Z, "resolve_identity",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("authz engaged!")))
    monkeypatch.setattr(Z, "authorize",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("authz engaged!")))

    import bot_squad_worker.actions as A
    calls = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: calls.append((name, params)) or {"ok": True})

    # A stranger (from_id 999, NOT in tg_users) /say in a private chat: legacy
    # behavior answers it (chat-level auth only), no per-user gating.
    msg = _slash_from("/say S-x-p1 hello", from_id=999, chat_id=12345)
    result = TL.handle_update(cfg, {"update_id": 1, "message": msg}, proj=proj)
    assert result["action"] == "say"
    assert calls == [("inject_input", {"sid": "S-x-p1", "text": "hello"})]


def test_authz_off_rate_limit_skipped_for_plain_message(tmp_path, monkeypatch):
    """tg_authz=False plain message never touches the rate limiter → brain runs."""
    cfg = _make_cfg(tmp_path, tg_authz=False, tg_chat="12345")
    proj = cfg.projects["test-project"]

    import bot_squad_worker.tg_authz as Z
    monkeypatch.setattr(Z, "check_turn_rate",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("rate limit engaged!")))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))

    msg = {"chat": {"id": 12345, "type": "private"},
           "from": {"id": 999, "first_name": "Stranger"}, "text": "hello"}
    result = TL.handle_update(cfg, {"update_id": 2, "message": msg}, proj=proj)
    assert result["action"] == "chat"


def test_authz_slash_control_cmds_neutralized(tmp_path, monkeypatch):
    """PIVOT: user-facing /status, /spawn, /say, /deploy are NEUTRALIZED for
    tg_authz projects — they no longer dispatch; they point the user at chat.
    The brain handles those intents from natural language instead."""
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                    tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")})
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("neutralized cmd must NOT dispatch")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))

    for i, text in enumerate(["/status test-project", "/spawn test-project backend",
                              "/say S-a-p1 hi", "/deploy test-project prod"]):
        msg = _slash_from(text, from_id=_TIM)
        r = TL.handle_update(cfg, {"update_id": 30 + i, "message": msg}, proj=proj)
        assert r["action"] == "neutralized_cmd"
    assert notes and "talk to me" in notes[0].lower()


def test_authz_help_points_to_conversation(tmp_path, monkeypatch):
    """/help still works and tells the user to just message naturally."""
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                    tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")})
    proj = cfg.projects["test-project"]
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    msg = _slash_from("/help", from_id=_TIM)
    r = TL.handle_update(cfg, {"update_id": 40, "message": msg}, proj=proj)
    assert r["action"] == "help"
    assert notes and "coordinator" in notes[0].lower()


def test_authz_on_rate_limit_trips_before_brain(tmp_path, monkeypatch):
    """tg_authz=True: per-from.id turn limit gates the brain. Over-limit →
    cheap canned reply, NO LLM turn (Thread never started)."""
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                    tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")})
    proj = cfg.projects["test-project"]
    import bot_squad_worker.tg_authz as Z
    # Force over-limit.
    monkeypatch.setattr(Z, "check_turn_rate", lambda *a, **k: False)
    thread_started = []
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: thread_started.append(1) or types.SimpleNamespace(start=lambda: None))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = {"chat": {"id": 12345, "type": "private"},
           "from": {"id": _TIM, "first_name": "Tim"}, "text": "hello"}
    result = TL.handle_update(cfg, {"update_id": 8, "message": msg}, proj=proj)
    assert result["action"] == "rate_limited"
    assert thread_started == []   # brain never spawned
    assert notes and "rate limit" in notes[0]


def test_authz_on_rate_limit_allows_under_limit(tmp_path, monkeypatch):
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                    tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")})
    proj = cfg.projects["test-project"]
    import bot_squad_worker.tg_authz as Z
    monkeypatch.setattr(Z, "check_turn_rate", lambda *a, **k: True)
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))
    msg = {"chat": {"id": 12345, "type": "private"},
           "from": {"id": _TIM, "first_name": "Tim"}, "text": "hello"}
    result = TL.handle_update(cfg, {"update_id": 9, "message": msg}, proj=proj)
    assert result["action"] == "chat"


def test_extract_slash_recognizes_status_and_spawn():
    assert TL.extract_slash_command(_slash_message("/status")) == ("status", "")
    assert TL.extract_slash_command(
        _slash_message("/spawn swarmdev backend")) == ("spawn", "swarmdev backend")


def test_extract_slash_recognizes_deploy_and_confirm():
    assert TL.extract_slash_command(
        _slash_message("/deploy test-project prod")) == ("deploy", "test-project prod")
    assert TL.extract_slash_command(_slash_message("/confirm")) == ("confirm", "")
    assert TL.extract_slash_command(
        _slash_message("/confirm abc123")) == ("confirm", "abc123")


# ---------------------------------------------------------------------------
# Phase 2: confirm-first gated-action flow (/deploy). All tg_authz=True.
# ---------------------------------------------------------------------------


def _plain_from(text, from_id, chat_id=None, chat_type="private"):
    chat_id = chat_id if chat_id is not None else from_id
    return {
        "message_id": 400,
        "chat": {"id": chat_id, "type": chat_type},
        "from": {"id": from_id, "first_name": "X"},
        "text": text,
    }


def _admin_cfg(tmp_path, **kw):
    return _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                     tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")}, **kw)


def _raise_deploy_pending(cfg, from_id=_TIM, chat_id=None, target="prod",
                          slug="test-project", role="admin"):
    """Seed a deploy pending exactly as the conversational brain now does
    (PIVOT: the slash /deploy raise UX is retired). The Phase-2 awaiting-confirm
    branch — which is REUSED unchanged — then consumes it on 'yes'/'/confirm'."""
    import bot_squad_worker.tg_pending as P
    chat_id = str(from_id) if chat_id is None else str(chat_id)
    return P.put(cfg.data_dir, chat_id, from_id, "deploy",
                 {"slug": slug, "target": target,
                  "reason": f"telegram coordinator brain by {from_id}",
                  "requested_by": f"tg:{from_id}"}, role)


def test_brain_deploy_needs_confirm_writes_pending_not_executed(tmp_path, monkeypatch):
    """Brain proposes a deploy block → needs_confirm: a pending record is
    written and A.dispatch is NOT called (no execution yet). The NL reply asks
    Tim to confirm."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    # Brain emits a deploy block + a confirm-ask in NL.
    monkeypatch.setattr(TL, "_claude_brain_turn",
                        lambda *a, **k: 'Deploying to prod is outward — reply yes to confirm.\n'
                                        '```swarm-action\n'
                                        '{"action":"deploy","params":{"slug":"test-project","target":"prod"}}\n'
                                        '```')
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("must NOT execute outward without confirm")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = _plain_from("deploy swarmdev to prod", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    # Pending persisted, not executed.
    pend = P.get_active(cfg.data_dir, str(_TIM), _TIM)
    assert pend is not None
    assert pend.action == "deploy"
    assert pend.params["slug"] == "test-project"
    assert pend.params["target"] == "prod"
    assert pend.params["requested_by"] == f"tg:{_TIM}"
    assert pend.raised_by == _TIM
    # NL reply (block STRIPPED) was posted and asks to confirm.
    assert notes
    posted = notes[-1]
    assert "swarm-action" not in posted          # block stripped from Tim's view
    assert "confirm" in posted.lower()
    assert "awaiting your confirmation" in posted.lower()


def test_correct_user_yes_dispatches_and_clears(tmp_path, monkeypatch):
    """Plain 'yes' from the RAISER → A.dispatch(deploy, params) + pending cleared."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    monkeypatch.setattr(TL, "_notify", lambda *a, **k: None)
    # Raise the pending the way the brain does.
    _raise_deploy_pending(cfg)
    assert P.get_active(cfg.data_dir, str(_TIM), _TIM) is not None

    calls = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: calls.append((name, params)) or {"ok": True, "queue_id": "q1"})

    yes = _plain_from("yes", from_id=_TIM)
    result = TL.handle_update(cfg, {"update_id": 12, "message": yes}, proj=proj)
    assert result["action"] == "confirmed"
    assert result["gated_action"] == "deploy"
    assert len(calls) == 1
    name, params = calls[0]
    assert name == "deploy"
    assert params["slug"] == "test-project" and params["target"] == "prod"
    assert params["requested_by"] == f"tg:{_TIM}"
    # Pending cleared after execution.
    assert P.get_active(cfg.data_dir, str(_TIM), _TIM) is None


def test_confirm_slash_with_token_dispatches(tmp_path, monkeypatch):
    """/confirm <token> from the raiser also executes the pending deploy."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    monkeypatch.setattr(TL, "_notify", lambda *a, **k: None)
    rec = _raise_deploy_pending(cfg)
    token = rec.token
    calls = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: calls.append((name, params)) or {"ok": True})
    confirm = _slash_from(f"/confirm {token}", from_id=_TIM)
    result = TL.handle_update(cfg, {"update_id": 14, "message": confirm}, proj=proj)
    assert result["action"] == "confirmed"
    assert calls and calls[0][0] == "deploy"
    assert P.get_active(cfg.data_dir, str(_TIM), _TIM) is None


def test_different_user_yes_does_not_confirm(tmp_path, monkeypatch):
    """CROSS-USER PROTECTION: user A raises a pending (in a group); user B's
    'yes' must NOT confirm it. B has no pending of their own → B's 'yes' falls
    through to the brain, and A's pending stays untouched (NOT executed)."""
    # Two known directors so both could otherwise dispatch.
    other = 555
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345", tg_users={
        _TIM: _tg_user(_TIM, "director", ["test-project"], "Tim"),
        other: _tg_user(other, "director", ["test-project"], "Ed"),
    })
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    monkeypatch.setattr(TL, "_notify", lambda *a, **k: None)
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))

    # Tim raises a deploy in the GROUP chat (chat_id 12345) — brain-style.
    _raise_deploy_pending(cfg, from_id=_TIM, chat_id=12345, role="director")
    assert P.get_active(cfg.data_dir, "12345", _TIM) is not None

    # dispatch must NEVER run from Ed's 'yes'.
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("cross-user confirm executed!")))
    ed_yes = _plain_from("yes", from_id=other, chat_id=12345, chat_type="supergroup")
    result = TL.handle_update(cfg, {"update_id": 16, "message": ed_yes}, proj=proj)
    # Ed's "yes" was not a confirmation → it reached the brain (chat).
    assert result["action"] == "chat"
    # Tim's pending is still there, unexecuted.
    assert P.get_active(cfg.data_dir, "12345", _TIM) is not None


def test_expired_pending_not_executed(tmp_path, monkeypatch):
    """An expired pending → 'expired' reply, dispatch NOT called, file cleared."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    # Write a pending that is already expired.
    P.put(cfg.data_dir, str(_TIM), _TIM, "deploy",
          {"slug": "test-project", "target": "prod", "reason": "r",
           "requested_by": f"tg:{_TIM}"}, "admin",
          now=1000.0 - P.TTL_SECONDS - 10)
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("expired must NOT execute")))

    yes = _plain_from("yes", from_id=_TIM)
    result = TL.handle_update(cfg, {"update_id": 17, "message": yes}, proj=proj)
    assert result["action"] == "confirm_expired"
    assert notes and "expired" in notes[0].lower()
    # Stale file cleared.
    assert not TL._has_pending_file(cfg, str(_TIM), _TIM)


def test_no_cancels_pending(tmp_path, monkeypatch):
    """Plain 'no' from the raiser → pending cleared, 'cancelled' reply, no dispatch."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    _raise_deploy_pending(cfg)
    assert P.get_active(cfg.data_dir, str(_TIM), _TIM) is not None

    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("'no' must NOT execute")))
    no = _plain_from("no", from_id=_TIM)
    result = TL.handle_update(cfg, {"update_id": 19, "message": no}, proj=proj)
    assert result["action"] == "confirm_cancelled"
    assert notes and "cancelled" in notes[-1].lower()
    assert P.get_active(cfg.data_dir, str(_TIM), _TIM) is None


def test_new_gated_request_supersedes_old_pending(tmp_path, monkeypatch):
    """A second deploy proposal supersedes the first; 'yes' executes the NEWER
    one only (tg_pending.put supersedes per (chat,from_id))."""
    cfg = _admin_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    monkeypatch.setattr(TL, "_notify", lambda *a, **k: None)
    _raise_deploy_pending(cfg, target="staging")
    _raise_deploy_pending(cfg, target="prod")
    calls = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: calls.append(params) or {"ok": True})
    TL.handle_update(cfg, {"update_id": 22, "message": _plain_from("yes", from_id=_TIM)},
                     proj=proj)
    assert len(calls) == 1
    assert calls[0]["target"] == "prod"   # newer request wins


def test_observer_brain_deploy_denied_no_pending(tmp_path, monkeypatch):
    """An unknown GROUP sender (observer) whose brain turn PROPOSES a deploy →
    the authorize broker DENIES it (envelope Principal, not LLM): NO pending
    written, NO dispatch, deny reason relayed. Confirm-first is only reachable
    by director/admin."""
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345", tg_users={})
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_pending as P
    monkeypatch.setattr(TL, "_claude_brain_turn",
                        lambda *a, **k: 'sure\n```swarm-action\n'
                                        '{"action":"deploy","params":{"slug":"test-project","target":"prod"}}\n```')
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("no dispatch for observer deploy")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    msg = _plain_from("deploy it", from_id=777, chat_id=12345, chat_type="supergroup")
    TL._run_brain_turn(cfg, proj, "TOK", "12345", "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert P.get_active(cfg.data_dir, "12345", 777) is None
    assert not TL._has_pending_file(cfg, "12345", 777)
    # Deny reason relayed in the reply.
    assert notes and "couldn't" in notes[-1].lower()


def test_authz_off_never_enters_confirm_flow(tmp_path, monkeypatch):
    """tg_authz=False (computation posture): /deploy is unrecognized, a plain
    'yes' is just chat. The pending store and confirm helpers are never touched —
    proving computation is byte-for-byte unaffected by Phase 2."""
    cfg = _make_cfg(tmp_path, tg_authz=False, tg_chat="12345")
    proj = cfg.projects["test-project"]
    import bot_squad_worker.tg_pending as P
    import bot_squad_worker.tg_authz as Z
    # If the confirm flow engaged, these would be hit.
    monkeypatch.setattr(P, "get_active",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("pending engaged!")))
    monkeypatch.setattr(Z, "resolve_identity",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("authz engaged!")))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))

    # (a) /deploy is unrecognized → not even a slash command for this project.
    assert TL.extract_slash_command(_slash_from("/deploy test-project prod", 999)) \
        == ("deploy", "test-project prod")
    dep = TL.handle_update(
        cfg, {"update_id": 23,
              "message": _slash_from("/deploy test-project prod", from_id=999, chat_id=12345)},
        proj=proj)
    assert dep["action"] == "unknown_cmd"

    # (b) a plain 'yes' is just chat, never a confirmation.
    yes = TL.handle_update(
        cfg, {"update_id": 24,
              "message": _plain_from("yes", from_id=999, chat_id=12345)},
        proj=proj)
    assert yes["action"] == "chat"


# ---------------------------------------------------------------------------
# Conversational COORDINATOR BRAIN (tg_authz). parse → authorize → dispatch.
# ---------------------------------------------------------------------------


def test_parse_action_block_extracts_and_strips():
    raw = ('Here you go, Tim.\n'
           '```swarm-action\n{"action":"status_summary","params":{"slug":"swarmdev"}}\n```')
    action, visible = TL._parse_action_block(raw)
    assert action == {"action": "status_summary", "params": {"slug": "swarmdev"}}
    assert "swarm-action" not in visible
    assert visible == "Here you go, Tim."


def test_parse_action_block_none_when_absent():
    action, visible = TL._parse_action_block("just chatting, no action here")
    assert action is None
    assert visible == "just chatting, no action here"


def test_parse_action_block_malformed_json_is_conversation():
    raw = 'ok\n```swarm-action\n{not valid json}\n```'
    action, visible = TL._parse_action_block(raw)
    assert action is None                      # malformed → pure conversation
    assert "swarm-action" not in visible       # block still stripped from view


def test_parse_action_block_missing_action_key():
    raw = 'hi\n```swarm-action\n{"params":{"slug":"x"}}\n```'
    action, visible = TL._parse_action_block(raw)
    assert action is None


def _brain_cfg(tmp_path, **kw):
    return _make_cfg(tmp_path, tg_authz=True, tg_chat="12345",
                     tg_users={_TIM: _tg_user(_TIM, "admin", ["*"], "Tim")}, **kw)


def test_brain_internal_action_dispatched_and_result_fed_back(tmp_path, monkeypatch):
    """Brain proposes status_summary → authorize allows → A.dispatch runs → ONE
    follow-up brain turn rewords the result → Tim sees NL (block stripped) + a
    short '(checked swarm status)' note."""
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")

    turns = iter([
        'Let me check.\n```swarm-action\n'
        '{"action":"status_summary","params":{"slug":"test-project"}}\n```',
        'Two workers are active and healthy.',          # follow-up reword
    ])
    monkeypatch.setattr(TL, "_claude_brain_turn", lambda *a, **k: next(turns))

    dispatched = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: dispatched.append((name, params))
                        or {"ok": True, "active_sessions": [1, 2]})
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = _plain_from("status?", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert dispatched == [("status_summary", {"slug": "test-project"})]
    assert notes
    posted = notes[-1]
    assert "swarm-action" not in posted               # block stripped
    assert "Two workers are active" in posted          # follow-up wording shown
    assert "checked swarm status" in posted            # action note appended


def test_brain_spawn_dispatched_with_note(tmp_path, monkeypatch):
    """A spawn proposal from admin is allowed, dispatched, and noted."""
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    turns = iter([
        'Spinning up a backend expert.\n```swarm-action\n'
        '{"action":"spawn_session","params":{"slug":"test-project",'
        '"window":"backend","role":"backend-expert"}}\n```',
        "It's up and starting on the task.",
    ])
    monkeypatch.setattr(TL, "_claude_brain_turn", lambda *a, **k: next(turns))
    dispatched = []
    monkeypatch.setattr(A, "dispatch",
                        lambda name, params: dispatched.append((name, params)) or {"ok": True, "sid": "S-new-p1"})
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = _plain_from("spin up a backend expert", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert dispatched and dispatched[0][0] == "spawn_session"
    assert notes and "spun up backend-expert" in notes[-1]


def test_brain_deny_relayed_no_dispatch(tmp_path, monkeypatch):
    """An observer's brain turn proposing spawn → authorize DENIES (envelope
    Principal) → no dispatch, deny reason relayed in the reply."""
    cfg = _make_cfg(tmp_path, tg_authz=True, tg_chat="12345", tg_users={})
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(TL, "_claude_brain_turn",
                        lambda *a, **k: 'sure\n```swarm-action\n'
                                        '{"action":"spawn_session","params":{"slug":"test-project",'
                                        '"window":"w","role":"r"}}\n```')
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("observer must NOT dispatch")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    # Unknown GROUP sender → observer (read-only).
    msg = _plain_from("spawn something", from_id=555, chat_id=12345, chat_type="supergroup")
    TL._run_brain_turn(cfg, proj, "TOK", "12345", "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert notes and "couldn't" in notes[-1].lower()


def test_brain_no_block_pure_conversation(tmp_path, monkeypatch):
    """No action block → pure conversation: no dispatch, no follow-up, the brain
    text is posted verbatim."""
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    calls = [0]

    def one_turn(*a, **k):
        calls[0] += 1
        return "Morning Tim! Feeling good about the refactor today."
    monkeypatch.setattr(TL, "_claude_brain_turn", one_turn)
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("no action → no dispatch")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = _plain_from("morning!", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert calls[0] == 1                          # exactly one turn, NO follow-up
    assert notes == ["Morning Tim! Feeling good about the refactor today."]


def test_brain_unknown_action_ignored(tmp_path, monkeypatch):
    """A block naming an action NOT in _BRAIN_ACTIONS is ignored (fail closed):
    no authorize, no dispatch, a quiet note."""
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.actions as A
    import bot_squad_worker.tg_authz as Z
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(TL, "_claude_brain_turn",
                        lambda *a, **k: 'ok\n```swarm-action\n'
                                        '{"action":"rm_rf_everything","params":{}}\n```')
    monkeypatch.setattr(A, "dispatch",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("unknown action must NOT dispatch")))
    monkeypatch.setattr(Z, "authorize",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("unknown action must NOT reach authorize")))
    notes = []
    monkeypatch.setattr(TL, "_notify", lambda c, t, ci, m: notes.append(m))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)

    msg = _plain_from("do something weird", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt")
    assert notes and "unsupported" in notes[-1].lower()


def test_brain_routing_replaces_handle_chat_for_authz(tmp_path, monkeypatch):
    """handle_update routes tg_authz plain messages to the ACTING brain
    (_handle_brain_chat), NOT the legacy tool-less _handle_chat."""
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    import bot_squad_worker.tg_authz as Z
    monkeypatch.setattr(Z, "check_turn_rate", lambda *a, **k: True)
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))
    monkeypatch.setattr(TL, "_handle_chat",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("legacy _handle_chat must NOT run for tg_authz")))
    msg = {"chat": {"id": _TIM, "type": "private"},
           "from": {"id": _TIM, "first_name": "Tim"}, "text": "hello"}
    result = TL.handle_update(cfg, {"update_id": 50, "message": msg}, proj=proj)
    assert result["action"] == "chat"


def test_computation_still_uses_legacy_handle_chat(tmp_path, monkeypatch):
    """tg_authz=False (computation): plain messages still go to the legacy
    tool-less _handle_chat — the brain pipeline is never engaged."""
    cfg = _make_cfg(tmp_path, tg_authz=False, tg_chat="12345")
    proj = cfg.projects["test-project"]
    monkeypatch.setattr(TL, "_handle_brain_chat",
                        lambda *a, **k: (_ for _ in ()).throw(AssertionError("brain must NOT run for tg_authz=False")))
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread",
                        lambda *a, **k: types.SimpleNamespace(start=lambda: None))
    msg = {"chat": {"id": 12345, "type": "private"},
           "from": {"id": 999, "first_name": "X"}, "text": "hello"}
    result = TL.handle_update(cfg, {"update_id": 51, "message": msg}, proj=proj)
    assert result["action"] == "chat"


# ---------------------------------------------------------------------------
# Shared coordinator working-memory blackboard (coord_context) integration.
# ---------------------------------------------------------------------------


def test_brain_seeding_includes_cross_instance_context(tmp_path, monkeypatch):
    """_handle_brain_chat seeds the prompt with the recent cross-instance
    blackboard, so the brain sees what Tim discussed with the terminal coord."""
    import bot_squad_worker.coord_context as CC
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    # Seed a terminal-coordinator entry on the shared blackboard.
    CC.append(cfg.data_dir, "test-project", "terminal", "coord",
              "Pivot: TG is a CONVERSATION, dropped slash UX.")

    captured = {}

    def fake_thread(target=None, args=(), daemon=None):
        # args: (cfg, proj, token, chat_id, cwd, sid, msg, prompt, system_prompt, text)
        captured["sysprompt"] = args[8]
        captured["inbound"] = args[9]
        return types.SimpleNamespace(start=lambda: None)

    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    monkeypatch.setattr(TL.threading, "Thread", fake_thread)

    msg = {"chat": {"id": _TIM, "type": "private"},
           "from": {"id": _TIM, "first_name": "Tim"}, "text": "remind me what we decided"}
    TL._handle_brain_chat(cfg, proj, str(_TIM), msg)
    sp = captured["sysprompt"]
    assert "Recent cross-instance context" in sp
    assert "terminal/coord" in sp
    assert "dropped slash UX" in sp
    # The raw inbound text is threaded through for the WRITE-back.
    assert captured["inbound"] == "remind me what we decided"


def test_brain_turn_writes_exchange_to_blackboard(tmp_path, monkeypatch):
    """After a turn, two instance='tg-brain' entries are appended: the inbound
    (speaker=tim) and the reply (speaker=coord, swarm-action block STRIPPED)."""
    import bot_squad_worker.coord_context as CC
    import bot_squad_worker.actions as A
    cfg = _brain_cfg(tmp_path)
    proj = cfg.projects["test-project"]
    monkeypatch.setattr(TL, "_seed_swarm_state", lambda slug: "{}")
    monkeypatch.setattr(TL, "_seed_project_state", lambda: "(state)")
    monkeypatch.setattr(TL, "_send_typing", lambda *a, **k: None)
    # Brain proposes a status action; follow-up rewords. Reply must end up on the
    # blackboard WITHOUT the swarm-action block.
    turns = iter([
        'Checking now.\n```swarm-action\n{"action":"status_summary","params":{"slug":"test-project"}}\n```',
        'All healthy — two workers up.',
    ])
    monkeypatch.setattr(TL, "_claude_brain_turn", lambda *a, **k: next(turns))
    monkeypatch.setattr(A, "dispatch", lambda n, p: {"ok": True})
    monkeypatch.setattr(TL, "_notify", lambda *a, **k: None)

    msg = _plain_from("status?", from_id=_TIM)
    TL._run_brain_turn(cfg, proj, "TOK", str(_TIM), "/tmp", "sid", msg,
                       "prompt", "sysprompt", inbound_text="status?")
    out = CC.read_recent(cfg.data_dir, "test-project")
    assert len(out) == 2
    assert out[0] == {"ts": out[0]["ts"], "instance": "tg-brain",
                      "speaker": "tim", "text": "status?"}
    assert out[1]["instance"] == "tg-brain"
    assert out[1]["speaker"] == "coord"
    # Reply recorded is the follow-up NL; never contains the action block.
    assert "swarm-action" not in out[1]["text"]
    assert "All healthy" in out[1]["text"]
