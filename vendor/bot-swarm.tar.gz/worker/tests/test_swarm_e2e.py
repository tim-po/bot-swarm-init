"""End-to-end test for the bot-swarm primitives.

Walks the full kettle in-process without tmux/claude:
1. A coordinator pane "exists" (we write its session md by hand, the way
   the SessionStart hook would after spawn() drops the role marker).
2. The coordinator sends a message to ``planner`` via the mail bus —
   no planner yet, so the message lands in the holding inbox.
3. A planner pane "spawns" — we seed its expert layout via
   _seed_expert_layout and write its session md.
4. Planner does inbox_read → drains the holding inbox into its own inbox
   and reads the queued message.
5. Planner replies via mail bus to ``coordinator`` (role keyword).
6. Coordinator reads the reply.
7. Bonus: a second-time round confirms broadcast to a role with two
   live sessions reaches both.

This proves the role-binding + holding-inbox + role-keyword routing
compose correctly. It does NOT cover the spawn() tmux side (those are
in test_sessions.py / test_actions.py).
"""
from __future__ import annotations

import types
from pathlib import Path

from bot_squad_worker import intersession as I
from bot_squad_worker.sessions import _seed_expert_layout


SLUG = "swarm-test"


def _make_cfg(tmp_path: Path) -> types.SimpleNamespace:
    return types.SimpleNamespace(data_dir=tmp_path / "data")


def _write_pane_session(tmp_path: Path, sid: str, role: str) -> None:
    """Simulate the SessionStart hook authoring a session md for a live
    pane bound to a swarm role.
    """
    sess_dir = tmp_path / "data" / SLUG / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    (sess_dir / f"{sid}.md").write_text(
        "---\n"
        f"sid: {sid}\n"
        "status: active\n"
        "task_id: ~\n"
        f"role: {role}\n"
        "---\n"
    )


def test_coordinator_planner_handshake_via_holding_then_role(tmp_path):
    cfg = _make_cfg(tmp_path)

    # 1. Coordinator pane is live.
    _seed_expert_layout(cfg, SLUG, "coordinator")
    coord_sid = "S-u-coord-p0"
    _write_pane_session(tmp_path, coord_sid, "coordinator")

    # 2. Coordinator sends to planner before any planner pane exists.
    sent = I.send(cfg, SLUG, coord_sid, "planner", "decompose I-0001")
    assert sent["delivered_to"] == []
    assert sent["held_for"] == "planner"

    holding = tmp_path / "data" / SLUG / "_chat" / "holding-planner.log"
    assert holding.exists()
    assert b"decompose I-0001" in holding.read_bytes()

    # 3. Planner pane spawns.
    _seed_expert_layout(cfg, SLUG, "planner")
    planner_sid = "S-u-plan-p1"
    _write_pane_session(tmp_path, planner_sid, "planner")
    # Identity.md should be the curated template, not the stub.
    planner_identity = (
        tmp_path / "data" / SLUG / "experts" / "planner" / "identity.md"
    )
    # Planner doesn't have a curated template yet — stub is fine.
    assert planner_identity.is_file()

    # 4. Planner reads → holding inbox drains into planner's inbox.
    read = I.inbox_read(cfg, SLUG, planner_sid)
    assert read["count"] == 1
    assert "decompose I-0001" in read["messages"][0]
    assert "[from " + coord_sid + "]" in read["messages"][0]
    # Holding is now empty.
    assert holding.read_bytes() == b""

    # 5. Planner replies to coordinator by role keyword.
    reply = I.send(cfg, SLUG, planner_sid, "coordinator", "9 tasks, 2 experts")
    assert reply["delivered_to"] == [coord_sid]
    assert "held_for" not in reply

    # 6. Coordinator reads the reply.
    coord_read = I.inbox_read(cfg, SLUG, coord_sid)
    assert coord_read["count"] == 1
    assert "9 tasks, 2 experts" in coord_read["messages"][0]


def test_role_broadcast_reaches_every_live_session(tmp_path):
    """Two backend-expert panes both receive a broadcast to the role."""
    cfg = _make_cfg(tmp_path)

    _seed_expert_layout(cfg, SLUG, "backend-expert")
    be1, be2 = "S-u-be1-p0", "S-u-be2-p1"
    _write_pane_session(tmp_path, be1, "backend-expert")
    _write_pane_session(tmp_path, be2, "backend-expert")
    coord = "S-u-coord-p2"
    _write_pane_session(tmp_path, coord, "coordinator")

    out = I.send(cfg, SLUG, coord, "backend-expert", "pull T-0001")
    assert sorted(out["delivered_to"]) == sorted([be1, be2])

    r1 = I.inbox_read(cfg, SLUG, be1)
    r2 = I.inbox_read(cfg, SLUG, be2)
    assert r1["count"] == 1 and r2["count"] == 1
    assert "pull T-0001" in r1["messages"][0]
    assert "pull T-0001" in r2["messages"][0]


def test_sid_addressing_bypasses_role_routing(tmp_path):
    """An ``S-…`` recipient is a literal SID even if a same-named role
    happens to exist — no surprise broadcast.
    """
    cfg = _make_cfg(tmp_path)
    target = "S-u-be1-p0"
    bystander = "S-u-be2-p1"
    _write_pane_session(tmp_path, target, "backend-expert")
    _write_pane_session(tmp_path, bystander, "backend-expert")
    coord = "S-u-coord-p2"
    _write_pane_session(tmp_path, coord, "coordinator")

    out = I.send(cfg, SLUG, coord, target, "you specifically")
    assert out["delivered_to"] == [target]

    r1 = I.inbox_read(cfg, SLUG, target)
    r2 = I.inbox_read(cfg, SLUG, bystander)
    assert r1["count"] == 1
    assert r2["count"] == 0


def test_holding_inbox_survives_multiple_pre_spawn_sends(tmp_path):
    """Multiple messages to a role with no live session queue up; the
    first session of that role to read drains all of them in order.
    """
    cfg = _make_cfg(tmp_path)
    coord = "S-u-coord-p0"
    _write_pane_session(tmp_path, coord, "coordinator")

    for i in range(3):
        out = I.send(cfg, SLUG, coord, "db-expert", f"queued {i}")
        assert out["held_for"] == "db-expert"

    # Spawn db-expert; first inbox_read drains everything in order.
    db_sid = "S-u-db-p7"
    _write_pane_session(tmp_path, db_sid, "db-expert")
    read = I.inbox_read(cfg, SLUG, db_sid)
    assert read["count"] == 3
    assert [m for m in read["messages"] if "queued 0" in m]
    assert [m for m in read["messages"] if "queued 1" in m]
    assert [m for m in read["messages"] if "queued 2" in m]
    # Order preserved.
    assert "queued 0" in read["messages"][0]
    assert "queued 1" in read["messages"][1]
    assert "queued 2" in read["messages"][2]
