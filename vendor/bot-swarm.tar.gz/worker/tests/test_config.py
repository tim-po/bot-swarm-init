"""Tests for worker.config."""
from __future__ import annotations

from pathlib import Path

import pytest

from bot_squad_worker.config import (
    Config, ConfigError, Project, TgUser, TgAuthzDefaults,
)


def test_load_finds_signal_tracker(tmp_config_dir: Path) -> None:
    cfg = Config.load(tmp_config_dir)
    assert "test-project" in cfg.projects
    proj = cfg.projects["test-project"]
    assert isinstance(proj, Project)
    assert proj.slug == "test-project"
    assert proj.repo_path == Path("/tmp/test-repo")
    assert "staging" in proj.deploy_targets


def test_load_missing_projects_toml_raises(tmp_path: Path) -> None:
    (tmp_path / "config").mkdir()
    with pytest.raises(FileNotFoundError):
        Config.load(tmp_path / "config")


def test_data_dir_resolves_relative_to_config(tmp_config_dir: Path) -> None:
    # Convention: data/ is sibling of config/.
    cfg = Config.load(tmp_config_dir)
    assert cfg.data_dir == tmp_config_dir.parent / "data"
    assert cfg.sock_path == tmp_config_dir.parent / "data" / "_sock" / "worker.sock"


def test_secrets_loads(tmp_config_dir: Path) -> None:
    (tmp_config_dir / "secrets.toml").write_text(
        '[telegram]\nbot_token = "TESTBOT:TOKEN"\n'
    )
    cfg = Config.load(tmp_config_dir)
    assert cfg.tg_bot_token == "TESTBOT:TOKEN"


def test_secrets_missing_raises(tmp_path: Path) -> None:
    # Build a config dir that has projects.toml but NOT secrets.toml.
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "projects.toml").write_text(
        '[projects.test-project]\n'
        'slug = "test-project"\n'
        'display_name = "Test Project"\n'
        'repo_path = "/tmp/test-repo"\n'
        'deploy_branch = "bot_squad/dev"\n'
        'master_branch = "master"\n'
        'prod_url = "https://example.com"\n'
        'staging_url = "https://staging.example.com"\n'
        'dev_url = "https://dev.example.com"\n'
        'deploy_targets = ["staging"]\n'
        'tg_chat = "0"\n'
        'created_at = 2026-05-10\n'
    )
    with pytest.raises(FileNotFoundError, match="secrets.toml"):
        Config.load(cfg_dir)


# --- F1 readiness gating: collect ALL missing required keys ----------------

def test_from_toml_collects_all_missing_keys() -> None:
    # Missing deploy_branch + tg_chat — must report BOTH, not just the first.
    raw = {
        "slug": "swarmdev",
        "display_name": "Swarm Dev",
        "repo_path": "/tmp/x",
        "master_branch": "master",
        "deploy_targets": ["staging"],
    }
    with pytest.raises(ConfigError) as ei:
        Project.from_toml(raw, slug_hint="swarmdev")
    msg = str(ei.value)
    assert "swarmdev" in msg
    assert "deploy_branch" in msg
    assert "tg_chat" in msg


def test_load_incomplete_project_raises_config_error(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = "x"\n')
    # deploy_branch + tg_chat missing.
    (cfg_dir / "projects.toml").write_text(
        '[projects.swarmdev]\n'
        'slug = "swarmdev"\n'
        'display_name = "Swarm Dev"\n'
        'repo_path = "/tmp/x"\n'
        'master_branch = "master"\n'
        'deploy_targets = ["staging"]\n'
    )
    with pytest.raises(ConfigError) as ei:
        Config.load(cfg_dir)
    msg = str(ei.value)
    assert "deploy_branch" in msg and "tg_chat" in msg
    assert "projects.toml" in msg


def test_load_malformed_toml_raises_config_error(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = "x"\n')
    (cfg_dir / "projects.toml").write_text('this = is = not = valid toml\n')
    with pytest.raises(ConfigError) as ei:
        Config.load(cfg_dir)
    assert "malformed TOML" in str(ei.value)


def test_load_valid_config_still_works(tmp_config_dir: Path) -> None:
    # No regression: the happy path still loads cleanly.
    cfg = Config.load(tmp_config_dir)
    assert "test-project" in cfg.projects


# ---------------------------------------------------------------------------
# Per-project Telegram bot config (T2 multi-bot refactor)
# ---------------------------------------------------------------------------


def _write_multi_bot_cfg(cfg_dir: Path) -> None:
    (cfg_dir / "projects.toml").write_text(
        '[projects.computation]\n'
        'slug = "computation"\n'
        'display_name = "computation"\n'
        'repo_path = "/home/claude/computation"\n'
        'deploy_branch = "main"\n'
        'master_branch = "main"\n'
        'deploy_targets = []\n'
        'tg_chat = "-5203063794"\n'
        'tg_enabled = true\n'
        '\n'
        '[projects.swarmdev]\n'
        'slug = "swarmdev"\n'
        'display_name = "swarmdev"\n'
        'repo_path = "/home/claude/swarmdev"\n'
        'deploy_branch = "main"\n'
        'master_branch = "main"\n'
        'deploy_targets = []\n'
        'tg_chat = "200974761"\n'
        'tg_enabled = false\n'
    )
    (cfg_dir / "secrets.toml").write_text(
        '[telegram]\n'
        'bot_token = "GLOBAL:TOKEN"\n'
        '\n'
        '[telegram_bots]\n'
        'swarmdev = "SWARMDEV:TOKEN"\n'
    )


def test_bot_token_per_project_and_global_fallback(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    _write_multi_bot_cfg(cfg_dir)
    cfg = Config.load(cfg_dir)
    # swarmdev has its own token.
    assert cfg.bot_token_for("swarmdev") == "SWARMDEV:TOKEN"
    # computation has no per-project entry -> global token fallback.
    assert cfg.bot_token_for("computation") == "GLOBAL:TOKEN"
    # Unknown slug also falls back to global.
    assert cfg.bot_token_for("nope") == "GLOBAL:TOKEN"
    assert cfg.telegram_bots == {"swarmdev": "SWARMDEV:TOKEN"}


def test_tg_enabled_parsed_and_defaults_false(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    _write_multi_bot_cfg(cfg_dir)
    cfg = Config.load(cfg_dir)
    assert cfg.projects["computation"].tg_enabled is True
    assert cfg.projects["swarmdev"].tg_enabled is False


def test_tg_enabled_defaults_false_when_absent(tmp_config_dir: Path) -> None:
    cfg = Config.load(tmp_config_dir)
    assert cfg.projects["test-project"].tg_enabled is False


def test_tg_enabled_via_tg_subtable(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "projects.toml").write_text(
        '[projects.x]\n'
        'slug = "x"\n'
        'display_name = "X"\n'
        'repo_path = "/tmp/x"\n'
        'deploy_branch = "main"\n'
        'master_branch = "main"\n'
        'deploy_targets = []\n'
        'tg_chat = "0"\n'
        '[projects.x.tg]\n'
        'enabled = true\n'
    )
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = "G"\n')
    cfg = Config.load(cfg_dir)
    assert cfg.projects["x"].tg_enabled is True


def test_enabled_tg_projects_excludes_disabled(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    _write_multi_bot_cfg(cfg_dir)
    cfg = Config.load(cfg_dir)
    enabled = {p.slug for p in cfg.enabled_tg_projects()}
    # computation enabled (global token resolvable); swarmdev disabled.
    assert enabled == {"computation"}


# ---------------------------------------------------------------------------
# Per-project tg_authz opt-in (multi-user directing, Phase 1)
# ---------------------------------------------------------------------------


def test_tg_authz_defaults_false_when_absent(tmp_config_dir: Path) -> None:
    cfg = Config.load(tmp_config_dir)
    assert cfg.projects["test-project"].tg_authz is False


def test_tg_authz_parsed_flat_and_subtable(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "projects.toml").write_text(
        '[projects.flat]\n'
        'slug = "flat"\n'
        'display_name = "Flat"\n'
        'repo_path = "/tmp/f"\n'
        'deploy_branch = "main"\n'
        'master_branch = "main"\n'
        'deploy_targets = []\n'
        'tg_chat = "0"\n'
        'tg_authz = true\n'
        '\n'
        '[projects.sub]\n'
        'slug = "sub"\n'
        'display_name = "Sub"\n'
        'repo_path = "/tmp/s"\n'
        'deploy_branch = "main"\n'
        'master_branch = "main"\n'
        'deploy_targets = []\n'
        'tg_chat = "0"\n'
        '[projects.sub.tg]\n'
        'authz = true\n'
    )
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = "G"\n')
    cfg = Config.load(cfg_dir)
    assert cfg.projects["flat"].tg_authz is True
    assert cfg.projects["sub"].tg_authz is True


def test_tg_users_missing_file_is_empty_map(tmp_config_dir: Path) -> None:
    # No tg_users.toml in tmp_config_dir → tolerated, empty map + defaults.
    cfg = Config.load(tmp_config_dir)
    assert cfg.tg_users == {}
    assert isinstance(cfg.tg_authz_defaults, TgAuthzDefaults)
    assert cfg.tg_authz_defaults.dm_unknown_role == "denied"
    assert cfg.tg_authz_defaults.group_member_role == "observer"


def test_tg_users_loaded_keyed_on_int_from_id(tmp_path: Path) -> None:
    cfg_dir = tmp_path / "config"
    cfg_dir.mkdir()
    (cfg_dir / "projects.toml").write_text(
        '[projects.x]\nslug = "x"\ndisplay_name = "X"\nrepo_path = "/tmp/x"\n'
        'deploy_branch = "main"\nmaster_branch = "main"\ndeploy_targets = []\n'
        'tg_chat = "0"\n'
    )
    (cfg_dir / "secrets.toml").write_text('[telegram]\nbot_token = "G"\n')
    (cfg_dir / "tg_users.toml").write_text(
        '[defaults]\n'
        'group_member_role = "observer"\n'
        'dm_unknown_role = "denied"\n'
        '\n'
        '[users.200974761]\n'
        'from_id = 200974761\n'
        'role = "admin"\n'
        'projects = ["*"]\n'
        'display = "Tim"\n'
    )
    cfg = Config.load(cfg_dir)
    assert set(cfg.tg_users) == {200974761}
    tim = cfg.tg_users[200974761]
    assert isinstance(tim, TgUser)
    assert tim.role == "admin"
    assert tim.projects == ("*",)
    assert tim.display == "Tim"
    assert tim.covers_project("anything")


def test_real_seed_file_has_tim_admin() -> None:
    """The shipped config/tg_users.toml seeds exactly Tim=admin/['*']."""
    cfg = Config.load(Path("/home/claude/bot-swarm/config"))
    assert 200974761 in cfg.tg_users
    tim = cfg.tg_users[200974761]
    assert tim.role == "admin"
    assert tim.projects == ("*",)
    assert tim.display == "Tim"
