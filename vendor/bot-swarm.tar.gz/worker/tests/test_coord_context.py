"""Tests for the shared coordinator working-memory blackboard."""
from __future__ import annotations

import json
from pathlib import Path

import bot_squad_worker.coord_context as CC


def _data(tmp_path: Path) -> Path:
    d = tmp_path / "data"
    (d / "_worker").mkdir(parents=True)
    return d


def test_append_read_recent_round_trip(tmp_path):
    data = _data(tmp_path)
    CC.append(data, "swarmdev", "tg-brain", "tim", "what's the status?")
    CC.append(data, "swarmdev", "tg-brain", "coord", "all healthy, 2 workers up")
    out = CC.read_recent(data, "swarmdev")
    assert len(out) == 2
    assert out[0]["instance"] == "tg-brain"
    assert out[0]["speaker"] == "tim"
    assert out[0]["text"] == "what's the status?"
    assert out[1]["speaker"] == "coord"
    assert out[1]["text"] == "all healthy, 2 workers up"
    # ts is an int epoch.
    assert isinstance(out[0]["ts"], int)


def test_read_recent_returns_last_n_only(tmp_path):
    data = _data(tmp_path)
    for i in range(40):
        CC.append(data, "swarmdev", "tg-brain", "tim", f"msg {i}")
    out = CC.read_recent(data, "swarmdev", n=10)
    assert len(out) == 10
    assert out[0]["text"] == "msg 30"     # oldest of the last 10
    assert out[-1]["text"] == "msg 39"    # newest


def test_read_recent_missing_file_is_empty(tmp_path):
    data = _data(tmp_path)
    assert CC.read_recent(data, "nope") == []


def test_read_recent_skips_corrupt_lines(tmp_path):
    data = _data(tmp_path)
    CC.append(data, "swarmdev", "tg-brain", "tim", "good one")
    # Inject a corrupt line directly.
    p = CC._path(data, "swarmdev")
    with p.open("a") as f:
        f.write("{not json}\n\n")
    CC.append(data, "swarmdev", "tg-brain", "coord", "another good one")
    out = CC.read_recent(data, "swarmdev")
    texts = [e["text"] for e in out]
    assert texts == ["good one", "another good one"]


def test_truncation_keeps_last_200(tmp_path):
    data = _data(tmp_path)
    p = CC._path(data, "swarmdev")

    # Append exactly up to the threshold-crossing: TRUNCATE_AT+1 entries. The
    # append that makes the file exceed TRUNCATE_AT triggers the rewrite to
    # KEEP_LINES, so right after, the file holds exactly KEEP_LINES lines.
    total = CC.TRUNCATE_AT + 1
    for i in range(total):
        CC.append(data, "swarmdev", "tg-brain", "tim", f"entry {i}")
    lines = p.read_text().splitlines()
    assert len(lines) == CC.KEEP_LINES                      # truncated to last 200
    out = CC.read_recent(data, "swarmdev", n=CC.KEEP_LINES)
    assert out[-1]["text"] == f"entry {total - 1}"          # newest survived
    assert out[0]["text"] == f"entry {total - CC.KEEP_LINES}"   # exactly 200 back

    # INVARIANT: the file is always bounded at <= TRUNCATE_AT, no matter how many
    # more we append (it grows from 200, re-truncates on the next crossing).
    for i in range(total, total + CC.TRUNCATE_AT + 50):
        CC.append(data, "swarmdev", "tg-brain", "tim", f"entry {i}")
        assert len(p.read_text().splitlines()) <= CC.TRUNCATE_AT


def test_append_swallows_bad_data_dir(tmp_path):
    # A file where a directory should be → mkdir/append fails, but never raises.
    bad = tmp_path / "afile"
    bad.write_text("x")
    # data_dir under a regular file → IO error, swallowed.
    CC.append(bad, "swarmdev", "tg-brain", "tim", "should not raise")
    assert CC.read_recent(bad, "swarmdev") == []


def test_append_skips_empty_text(tmp_path):
    data = _data(tmp_path)
    CC.append(data, "swarmdev", "tg-brain", "tim", "   ")
    assert CC.read_recent(data, "swarmdev") == []
