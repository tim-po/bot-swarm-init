"""Tests for bot_squad_worker.tg_authz — identity resolution, capability tiers,
authorize() allow/deny/needs_confirm, and the per-from.id rate limiter.

All pure / filesystem-injectable; no network, no subprocess.
"""
from __future__ import annotations

import types
from pathlib import Path

import pytest

import bot_squad_worker.tg_authz as Z


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tg_user(from_id, role, projects, display=""):
    return types.SimpleNamespace(
        from_id=from_id, role=role, projects=tuple(projects), display=display,
        covers_project=lambda slug, p=tuple(projects): "*" in p or slug in p,
    )


def _cfg(users=None, group_member_role="observer", dm_unknown_role="denied"):
    return types.SimpleNamespace(
        tg_users=users or {},
        tg_authz_defaults=types.SimpleNamespace(
            group_member_role=group_member_role,
            dm_unknown_role=dm_unknown_role,
        ),
    )


def _dm(from_id):
    return {"chat": {"id": from_id, "type": "private"},
            "from": {"id": from_id, "first_name": "X"}, "text": "hi"}


def _group(from_id, chat_id=-100):
    return {"chat": {"id": chat_id, "type": "supergroup"},
            "from": {"id": from_id, "first_name": "X"}, "text": "hi"}


_PROJ = types.SimpleNamespace(slug="swarmdev")


# ---------------------------------------------------------------------------
# resolve_identity
# ---------------------------------------------------------------------------


def test_resolve_dm_known_admin():
    cfg = _cfg({200974761: _tg_user(200974761, "admin", ["*"], "Tim")})
    p = Z.resolve_identity(cfg, _dm(200974761), _PROJ)
    assert p.from_id == 200974761
    assert p.role == "admin"
    assert p.projects == ("*",)
    assert p.source == "dm_record"
    assert p.covers_project("anything")


def test_resolve_dm_unknown_denied():
    cfg = _cfg()  # no users; dm_unknown_role default "denied"
    p = Z.resolve_identity(cfg, _dm(999), _PROJ)
    assert p.role == "denied"
    assert p.source == "dm_unknown"
    # Scoped to the receiving project only (never "*").
    assert p.projects == ("swarmdev",)


def test_resolve_group_known_uses_record():
    cfg = _cfg({42: _tg_user(42, "director", ["swarmdev"], "Ed")})
    p = Z.resolve_identity(cfg, _group(42), _PROJ)
    assert p.role == "director"
    assert p.source == "group_record"
    assert p.projects == ("swarmdev",)


def test_resolve_group_unknown_observer_scoped():
    cfg = _cfg()  # group_member_role default "observer"
    p = Z.resolve_identity(cfg, _group(777), _PROJ)
    assert p.role == "observer"
    assert p.source == "group_unknown"
    # Scoped to THIS project only — never "*".
    assert p.projects == ("swarmdev",)
    assert not p.covers_project("computation")
    assert p.covers_project("swarmdev")


# ---------------------------------------------------------------------------
# Capability tiers
# ---------------------------------------------------------------------------


def test_caps_for_tiers():
    assert Z.caps_for("denied") == frozenset()
    assert Z.caps_for("observer") == frozenset({"read"})
    assert "inject_own" in Z.caps_for("member")
    assert "read" in Z.caps_for("member")
    assert "dispatch" not in Z.caps_for("member")
    assert "dispatch" in Z.caps_for("director")
    assert "inject_any" in Z.caps_for("director")
    assert "all" in Z.caps_for("admin")
    # Unknown role → no caps.
    assert Z.caps_for("wizard") == frozenset()


# ---------------------------------------------------------------------------
# authorize — allow / deny / needs_confirm
# ---------------------------------------------------------------------------


def _admin():
    return Z.Principal(200974761, "admin", ("*",), "dm_record")


def _observer():
    return Z.Principal(777, "observer", ("swarmdev",), "group_unknown")


def _member():
    return Z.Principal(7, "member", ("swarmdev",), "dm_record")


def _director():
    return Z.Principal(42, "director", ("swarmdev",), "dm_record")


def test_authorize_admin_status_allow():
    d = Z.authorize(_admin(), "status", {"slug": "swarmdev"})
    assert d.allowed


def test_authorize_observer_can_read_not_dispatch():
    assert Z.authorize(_observer(), "status", {"slug": "swarmdev"}).allowed
    d = Z.authorize(_observer(), "spawn", {"slug": "swarmdev"})
    assert d.denied
    assert "cannot 'spawn'" in d.reason


def test_authorize_denied_role_has_no_caps():
    p = Z.Principal(999, "denied", ("swarmdev",), "dm_unknown")
    d = Z.authorize(p, "status", {"slug": "swarmdev"})
    assert d.denied
    assert "no capabilities" in d.reason


def test_authorize_project_scope_denies_out_of_scope():
    d = Z.authorize(_director(), "spawn", {"slug": "computation"})
    assert d.denied
    assert "not in scope" in d.reason


def test_authorize_director_spawn_in_scope_allows():
    d = Z.authorize(_director(), "spawn", {"slug": "swarmdev"})
    assert d.allowed


def test_authorize_member_inject_own_allows_and_foreign_denies():
    # Member injecting into their OWN session (owner == from_id) is allowed.
    assert Z.authorize(_member(), "inject", {"owner": 7}).allowed
    # Member injecting into someone else's session is denied.
    d = Z.authorize(_member(), "inject", {"owner": 999})
    assert d.denied
    assert "your own sessions" in d.reason


def test_authorize_director_inject_any_bypasses_ownership():
    # director/admin have inject_any → can inject into a foreign-owned session.
    assert Z.authorize(_director(), "inject", {"owner": 999}).allowed
    assert Z.authorize(_admin(), "inject", {"owner": 999}).allowed


def test_authorize_outward_needs_confirm_even_for_admin():
    d = Z.authorize(_admin(), "deploy", {"slug": "swarmdev"})
    assert d.needs_confirm
    # money/* convention also outward.
    assert Z.authorize(_admin(), "money/transfer", {}).needs_confirm


def test_authorize_unknown_action_fails_closed_for_non_admin():
    d = Z.authorize(_director(), "nuke", {})
    assert d.denied
    # admin ('all') still allowed for unmapped non-outward action.
    assert Z.authorize(_admin(), "nuke", {}).allowed


# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------


def test_turn_rate_trips_after_limit(tmp_path):
    data_dir = tmp_path
    (data_dir / "_worker").mkdir()
    fid = 200974761
    # First TURN_LIMIT_PER_HOUR calls allowed.
    for i in range(Z.TURN_LIMIT_PER_HOUR):
        assert Z.check_turn_rate(data_dir, fid) is True, f"call {i} should pass"
    # Next one is over the limit.
    assert Z.check_turn_rate(data_dir, fid) is False


def test_dispatch_rate_stricter(tmp_path):
    data_dir = tmp_path
    (data_dir / "_worker").mkdir()
    fid = 42
    for i in range(Z.DISPATCH_LIMIT_PER_HOUR):
        assert Z.check_dispatch_rate(data_dir, fid) is True
    assert Z.check_dispatch_rate(data_dir, fid) is False


def test_rate_window_prunes_old(tmp_path, monkeypatch):
    data_dir = tmp_path
    (data_dir / "_worker").mkdir()
    fid = 1
    now = 1_000_000.0
    # Fill the dispatch bucket at t=now.
    for _ in range(Z.DISPATCH_LIMIT_PER_HOUR):
        assert Z.check_dispatch_rate(data_dir, fid, now=now) is True
    assert Z.check_dispatch_rate(data_dir, fid, now=now) is False
    # An hour + later, the window has slid → allowed again.
    later = now + Z._WINDOW_SECONDS + 1
    assert Z.check_dispatch_rate(data_dir, fid, now=later) is True


def test_authorize_dispatch_rate_hook_denies(tmp_path):
    data_dir = tmp_path
    (data_dir / "_worker").mkdir()
    p = _director()
    # Exhaust the dispatch budget through authorize itself.
    for _ in range(Z.DISPATCH_LIMIT_PER_HOUR):
        assert Z.authorize(p, "spawn", {"slug": "swarmdev"},
                           data_dir=data_dir).allowed
    d = Z.authorize(p, "spawn", {"slug": "swarmdev"}, data_dir=data_dir)
    assert d.denied
    assert "rate limit" in d.reason
    # Read-only actions are NOT dispatch-rate-limited.
    assert Z.authorize(p, "status", {"slug": "swarmdev"},
                       data_dir=data_dir).allowed
