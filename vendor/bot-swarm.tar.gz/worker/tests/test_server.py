"""Tests for worker FastAPI app on Unix socket."""
from __future__ import annotations

from fastapi.testclient import TestClient

from bot_squad_worker.server import build_app


def test_health_endpoint():
    app = build_app()
    with TestClient(app) as client:
        r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["ok"] is True
    assert "version" in body
    assert "uptime" in body


def test_actions_noop():
    app = build_app()
    with TestClient(app) as client:
        r = client.post("/actions/noop", json={})
    assert r.status_code == 200
    assert r.json()["ok"] is True


def test_actions_unknown_returns_400():
    app = build_app()
    with TestClient(app) as client:
        r = client.post("/actions/wipe-disk", json={})
    assert r.status_code == 400
    assert "unknown action" in r.json()["detail"]


def test_actions_bad_params_returns_400():
    app = build_app()
    with TestClient(app) as client:
        r = client.post("/actions/noop", json={"oops": 1})
    assert r.status_code == 400


# --- F1 readiness gating: degraded mode -----------------------------------

def test_degraded_health_reports_error():
    from bot_squad_worker import actions as A
    A.set_degraded("config/projects.toml: missing required keys: deploy_branch")
    try:
        app = build_app()
        with TestClient(app) as client:
            r = client.get("/health")
        assert r.status_code == 200
        body = r.json()
        assert body["ok"] is False
        assert body.get("degraded") is True
        assert "deploy_branch" in body["error"]
    finally:
        A.set_degraded("")  # clear so other tests see a healthy worker


def test_degraded_action_returns_503_with_detail():
    from bot_squad_worker import actions as A
    A.set_degraded("config/projects.toml: missing required keys: tg_chat")
    try:
        app = build_app()
        with TestClient(app) as client:
            r = client.post("/actions/noop", json={})
        assert r.status_code == 503
        assert "tg_chat" in r.json()["detail"]
    finally:
        A.set_degraded("")
