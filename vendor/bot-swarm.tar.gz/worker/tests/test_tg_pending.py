"""Tests for bot_squad_worker.tg_pending — the confirm-first pending store.

Pure filesystem over an injectable data_dir; no network, no subprocess.
"""
from __future__ import annotations

from pathlib import Path

import bot_squad_worker.tg_pending as P


_PARAMS = {"slug": "swarmdev", "target": "prod", "reason": "r", "requested_by": "tg:1"}


def test_put_then_get_active(tmp_path):
    rec = P.put(tmp_path, chat_id="12345", from_id=1, action="deploy",
                params=_PARAMS, role="admin", now=1000.0)
    assert rec.action == "deploy"
    assert rec.raised_by == 1
    assert rec.expires_at == 1000.0 + P.TTL_SECONDS
    got = P.get_active(tmp_path, "12345", 1, now=1100.0)
    assert got is not None
    assert got.token == rec.token
    assert got.params == _PARAMS


def test_get_active_none_when_no_record(tmp_path):
    assert P.get_active(tmp_path, "12345", 1) is None


def test_get_active_expired_returns_none(tmp_path):
    P.put(tmp_path, "12345", 1, "deploy", _PARAMS, "admin", now=1000.0)
    # just before expiry → active; at/after expiry → None.
    assert P.get_active(tmp_path, "12345", 1, now=1000.0 + P.TTL_SECONDS - 1) is not None
    assert P.get_active(tmp_path, "12345", 1, now=1000.0 + P.TTL_SECONDS) is None
    assert P.get_active(tmp_path, "12345", 1, now=1000.0 + P.TTL_SECONDS + 50) is None


def test_put_supersedes_existing(tmp_path):
    first = P.put(tmp_path, "12345", 1, "deploy",
                  {**_PARAMS, "target": "staging"}, "admin", now=1000.0)
    second = P.put(tmp_path, "12345", 1, "deploy",
                   {**_PARAMS, "target": "prod"}, "admin", now=1010.0)
    assert first.token != second.token
    got = P.get_active(tmp_path, "12345", 1, now=1020.0)
    # The newer record wins; only one file exists for the key.
    assert got.token == second.token
    assert got.params["target"] == "prod"


def test_distinct_keys_per_chat_and_from(tmp_path):
    P.put(tmp_path, "12345", 1, "deploy", _PARAMS, "admin", now=1000.0)
    P.put(tmp_path, "12345", 2, "deploy", _PARAMS, "admin", now=1000.0)
    # Different from_id in the same chat → separate records (cross-user safety).
    a = P.get_active(tmp_path, "12345", 1, now=1001.0)
    b = P.get_active(tmp_path, "12345", 2, now=1001.0)
    assert a is not None and b is not None
    assert a.token != b.token
    # And user 3 has nothing.
    assert P.get_active(tmp_path, "12345", 3, now=1001.0) is None


def test_clear_removes_record(tmp_path):
    P.put(tmp_path, "12345", 1, "deploy", _PARAMS, "admin", now=1000.0)
    P.clear(tmp_path, "12345", 1)
    assert P.get_active(tmp_path, "12345", 1, now=1001.0) is None
    # idempotent
    P.clear(tmp_path, "12345", 1)


def test_negative_group_chat_id_filename_safe(tmp_path):
    rec = P.put(tmp_path, chat_id=-1001234567890, from_id=999,
                action="deploy", params=_PARAMS, role="director", now=1000.0)
    got = P.get_active(tmp_path, -1001234567890, 999, now=1001.0)
    assert got is not None and got.token == rec.token


def test_corrupt_record_returns_none(tmp_path):
    P.put(tmp_path, "12345", 1, "deploy", _PARAMS, "admin", now=1000.0)
    p = P._path(tmp_path, "12345", 1)
    p.write_text("not json {{{")
    assert P.get_active(tmp_path, "12345", 1, now=1001.0) is None
