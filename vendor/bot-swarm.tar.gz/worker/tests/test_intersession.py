"""Tests for the cross-session message bus (bot_squad_worker.intersession)."""
from __future__ import annotations

import threading
import time
import types
from pathlib import Path

import pytest

from bot_squad_worker import intersession as I


def _make_cfg(tmp_path: Path) -> types.SimpleNamespace:
    return types.SimpleNamespace(data_dir=tmp_path / "data")


def _write_session(tmp_path: Path, slug: str, sid: str, task_id: str = "") -> None:
    sess_dir = tmp_path / "data" / slug / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    (sess_dir / f"{sid}.md").write_text(
        "---\n"
        f"sid: {sid}\n"
        "status: active\n"
        f"task_id: {task_id or '~'}\n"
        "---\n"
    )


def test_send_then_read_roundtrip(tmp_path):
    cfg = _make_cfg(tmp_path)
    out = I.send(cfg, "p", "S-from", "S-to", "hello world")
    assert out["ok"] is True
    assert out["delivered_to"] == ["S-to"]
    read = I.inbox_read(cfg, "p", "S-to")
    assert read["count"] == 1
    assert "hello world" in read["messages"][0]
    assert "[from S-from]" in read["messages"][0]


def test_read_idempotent_after_drain(tmp_path):
    cfg = _make_cfg(tmp_path)
    I.send(cfg, "p", "S-from", "S-to", "one")
    I.send(cfg, "p", "S-from", "S-to", "two")
    first = I.inbox_read(cfg, "p", "S-to")
    assert first["count"] == 2
    second = I.inbox_read(cfg, "p", "S-to")
    assert second["count"] == 0


def test_send_to_unknown_sid_still_writes_inbox(tmp_path):
    """An SID with no sessions/*.md entry should still get its own inbox file."""
    cfg = _make_cfg(tmp_path)
    out = I.send(cfg, "p", "S-from", "S-ghost", "boo")
    assert out["delivered_to"] == ["S-ghost"]
    inbox = tmp_path / "data" / "p" / "_chat" / "inbox-S-ghost.log"
    assert inbox.exists()
    read = I.inbox_read(cfg, "p", "S-ghost")
    assert read["count"] == 1


def test_text_sanitisation(tmp_path):
    cfg = _make_cfg(tmp_path)
    long = "x" * 5000
    I.send(cfg, "p", "S-from", "S-to", "line1\nline2\rline3\r\nline4")
    I.send(cfg, "p", "S-from", "S-to", long)
    read = I.inbox_read(cfg, "p", "S-to")
    assert len(read["messages"]) == 2
    # Newlines collapsed to spaces — message line has no embedded \n
    assert "\n" not in read["messages"][0]
    assert "line1 line2 line3 line4" in read["messages"][0]
    # 4000-char cap
    assert read["messages"][1].endswith("x" * 100)
    # Total length budget = ts + "[from S-from]\t" + body; body <= 4000
    assert read["messages"][1].count("x") == 4000


def test_role_fanout_teamlead_and_dev(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_session(tmp_path, "p", "S-u-tl1-p0")           # teamlead (no task_id)
    _write_session(tmp_path, "p", "S-u-tl2-p1")           # teamlead
    _write_session(tmp_path, "p", "S-u-w1-p2", "T-0001")  # dev
    _write_session(tmp_path, "p", "S-u-w2-p3", "T-0002")  # dev

    tl = I.send(cfg, "p", "S-orchestrator", "teamlead", "hi TLs")
    assert sorted(tl["delivered_to"]) == ["S-u-tl1-p0", "S-u-tl2-p1"]

    dv = I.send(cfg, "p", "S-orchestrator", "dev", "hi devs")
    assert sorted(dv["delivered_to"]) == ["S-u-w1-p2", "S-u-w2-p3"]

    al = I.send(cfg, "p", "S-orchestrator", "all", "hi everyone")
    assert sorted(al["delivered_to"]) == sorted([
        "S-u-tl1-p0", "S-u-tl2-p1", "S-u-w1-p2", "S-u-w2-p3",
    ])


def test_wait_timeout_returns_not_ready(tmp_path):
    cfg = _make_cfg(tmp_path)
    t0 = time.monotonic()
    out = I.inbox_wait(cfg, "p", "S-to", timeout=1.5)
    elapsed = time.monotonic() - t0
    assert out["ok"] is True
    assert out["ready"] is False
    assert 1.0 <= elapsed <= 3.5
    assert out["elapsed_sec"] >= 1.0


def test_wait_returns_ready_when_inbox_grows(tmp_path):
    cfg = _make_cfg(tmp_path)

    def writer():
        time.sleep(0.4)
        I.send(cfg, "p", "S-from", "S-to", "ping")

    t = threading.Thread(target=writer, daemon=True)
    t.start()
    out = I.inbox_wait(cfg, "p", "S-to", timeout=5)
    t.join(timeout=2)
    assert out["ready"] is True
    # And a follow-up read drains the message.
    read = I.inbox_read(cfg, "p", "S-to")
    assert read["count"] == 1


def test_wait_caps_timeout(tmp_path, monkeypatch):
    """Timeout > 1800 should be clamped."""
    cfg = _make_cfg(tmp_path)
    # Patch time.sleep + monotonic to verify clamp without burning 1800s.
    calls: list[float] = []
    real_monotonic = time.monotonic
    start = real_monotonic()
    fake_now = [start]

    def fake_monotonic():
        return fake_now[0]

    def fake_sleep(s):
        calls.append(s)
        fake_now[0] += s

    monkeypatch.setattr(I.time, "monotonic", fake_monotonic)
    monkeypatch.setattr(I.time, "sleep", fake_sleep)
    out = I.inbox_wait(cfg, "p", "S-to", timeout=9999)
    assert out["ready"] is False
    # Should have slept its way to roughly 1800s, not 9999s.
    assert sum(calls) <= 1801
    assert out["elapsed_sec"] <= 1801


def test_chat_dir_created_with_group_write(tmp_path):
    cfg = _make_cfg(tmp_path)
    I.send(cfg, "p", "S-from", "S-to", "hi")
    chat = tmp_path / "data" / "p" / "_chat"
    assert chat.is_dir()
    mode = chat.stat().st_mode & 0o777
    # Some tmpfs / CI filesystems strip group-write; assert at least the
    # owner+group can write. The chmod is best-effort.
    assert mode & 0o600


# ---------------------------------------------------------------------------
# Bot-swarm: role keyword routing + holding inbox
# ---------------------------------------------------------------------------

def _write_session_with_role(tmp_path: Path, slug: str, sid: str, role: str) -> None:
    sess_dir = tmp_path / "data" / slug / "sessions"
    sess_dir.mkdir(parents=True, exist_ok=True)
    (sess_dir / f"{sid}.md").write_text(
        "---\n"
        f"sid: {sid}\n"
        "status: active\n"
        "task_id: ~\n"
        f"role: {role}\n"
        "---\n"
    )


def test_send_to_role_matches_sessions_by_role(tmp_path):
    cfg = _make_cfg(tmp_path)
    _write_session_with_role(tmp_path, "p", "S-u-w1-p0", "backend-expert")
    _write_session_with_role(tmp_path, "p", "S-u-w2-p1", "backend-expert")
    _write_session_with_role(tmp_path, "p", "S-u-w3-p2", "frontend-expert")

    out = I.send(cfg, "p", "S-coordinator", "backend-expert", "go")
    assert sorted(out["delivered_to"]) == ["S-u-w1-p0", "S-u-w2-p1"]
    assert "held_for" not in out

    read1 = I.inbox_read(cfg, "p", "S-u-w1-p0")
    read2 = I.inbox_read(cfg, "p", "S-u-w2-p1")
    read3 = I.inbox_read(cfg, "p", "S-u-w3-p2")
    assert read1["count"] == 1
    assert read2["count"] == 1
    assert read3["count"] == 0  # different role, no delivery


def test_send_to_role_with_no_live_sessions_goes_to_holding(tmp_path):
    cfg = _make_cfg(tmp_path)
    # No sessions exist at all.
    out = I.send(cfg, "p", "S-coordinator", "db-expert", "first message")
    assert out["delivered_to"] == []
    assert out.get("held_for") == "db-expert"

    holding = tmp_path / "data" / "p" / "_chat" / "holding-db-expert.log"
    assert holding.exists()
    assert b"first message" in holding.read_bytes()


def test_role_holding_inbox_drains_on_first_read(tmp_path):
    """Messages addressed to a role before any session of that role exists
    are delivered to the first session of that role to call inbox_read."""
    cfg = _make_cfg(tmp_path)
    # Send while no db-expert exists yet.
    I.send(cfg, "p", "S-coordinator", "db-expert", "queued one")
    I.send(cfg, "p", "S-coordinator", "db-expert", "queued two")

    # Now a db-expert session spawns.
    _write_session_with_role(tmp_path, "p", "S-u-db-p0", "db-expert")

    # First inbox_read drains holding into this session's inbox.
    read = I.inbox_read(cfg, "p", "S-u-db-p0")
    assert read["count"] == 2
    assert "queued one" in read["messages"][0]
    assert "queued two" in read["messages"][1]

    # Holding inbox is now empty.
    holding = tmp_path / "data" / "p" / "_chat" / "holding-db-expert.log"
    assert holding.read_bytes() == b""

    # Second read sees nothing new.
    again = I.inbox_read(cfg, "p", "S-u-db-p0")
    assert again["count"] == 0


# ---------------------------------------------------------------------------
# S2: atomic claim-via-rename drain of the holding inbox
# ---------------------------------------------------------------------------


def test_drain_holding_no_double_deliver_across_crash(tmp_path):
    """Simulate a crash in the PROTECTED window (after the claim is committed
    — appended + emptied — but before it is unlinked). Recovery by the same
    sid must clean up the orphaned empty claim WITHOUT re-appending: the line
    is delivered exactly once. This is the common crash window; the original
    read-append-truncate bug re-delivered on every subsequent holding read.
    """
    cfg = _make_cfg(tmp_path)
    # Send while no db-expert is live so the line lands in holding.
    I.send(cfg, "p", "S-coordinator", "db-expert", "queued one")
    _write_session_with_role(tmp_path, "p", "S-u-db-p0", "db-expert")

    chat = tmp_path / "data" / "p" / "_chat"
    holding = chat / "holding-db-expert.log"
    inbox = chat / "inbox-S-u-db-p0.log"

    # Patch _drain_one_claim to simulate a crash right after the commit point
    # (append + truncate-claim-to-empty) but BEFORE the unlink.
    import bot_squad_worker.intersession as IS
    real_drain_one = IS._drain_one_claim
    crashed = {"done": False}

    def crashing_drain_one(claim, inbox_path):
        if not crashed["done"]:
            crashed["done"] = True
            buf = claim.read_bytes()
            if buf:
                with inbox_path.open("ab") as f:
                    f.write(buf)
                claim.write_bytes(b"")  # commit: empty the claim
            return  # "crash": leave the empty claim in place (no unlink)
        return real_drain_one(claim, inbox_path)

    orig = IS._drain_one_claim
    IS._drain_one_claim = crashing_drain_one
    try:
        IS._drain_holding(cfg, "p", "db-expert", "S-u-db-p0")
    finally:
        IS._drain_one_claim = orig

    # Holding consumed; an orphaned (but already-committed, empty) claim remains.
    claims = list(chat.glob("holding-db-expert.log.*.claim"))
    assert len(claims) == 1, "expected one orphaned claim after simulated crash"
    assert claims[0].read_bytes() == b"", "committed claim should be empty"
    # Delivered exactly once so far.
    assert inbox.read_bytes().count(b"queued one") == 1

    # Recovery drain by the SAME sid: cleans up the orphan, does NOT re-append.
    IS._drain_holding(cfg, "p", "db-expert", "S-u-db-p0")
    assert list(chat.glob("holding-db-expert.log.*.claim")) == []
    assert inbox.read_bytes().count(b"queued one") == 1  # no double-deliver

    # inbox_read surfaces it exactly once.
    read = I.inbox_read(cfg, "p", "S-u-db-p0")
    assert read["count"] == 1
    assert "queued one" in read["messages"][0]


def test_drain_holding_crash_before_commit_is_at_least_once(tmp_path):
    """A crash BEFORE the commit point (appended but claim not yet emptied)
    is the one window where recovery re-appends. Verify the bound: the line is
    delivered at-least-once (never LOST) and the orphan is cleaned up — strictly
    better than the original bug, which re-delivered on every later read.
    """
    cfg = _make_cfg(tmp_path)
    I.send(cfg, "p", "S-coordinator", "db-expert", "queued one")
    _write_session_with_role(tmp_path, "p", "S-u-db-p0", "db-expert")

    chat = tmp_path / "data" / "p" / "_chat"
    inbox = chat / "inbox-S-u-db-p0.log"

    import bot_squad_worker.intersession as IS
    real_drain_one = IS._drain_one_claim
    crashed = {"done": False}

    def crashing_drain_one(claim, inbox_path):
        if not crashed["done"]:
            crashed["done"] = True
            buf = claim.read_bytes()
            with inbox_path.open("ab") as f:
                f.write(buf)
            return  # "crash" BEFORE emptying the claim (non-empty orphan left)
        return real_drain_one(claim, inbox_path)

    IS._drain_one_claim = crashing_drain_one
    try:
        IS._drain_holding(cfg, "p", "db-expert", "S-u-db-p0")
    finally:
        IS._drain_one_claim = real_drain_one

    # One non-empty orphan, delivered once so far.
    claims = list(chat.glob("holding-db-expert.log.*.claim"))
    assert len(claims) == 1 and claims[0].read_bytes() != b""
    assert inbox.read_bytes().count(b"queued one") == 1

    # Recovery cleans up the orphan; no lines lost (delivered at least once),
    # and no claim left behind to re-deliver unboundedly.
    IS._drain_holding(cfg, "p", "db-expert", "S-u-db-p0")
    assert list(chat.glob("holding-db-expert.log.*.claim")) == []
    assert inbox.read_bytes().count(b"queued one") >= 1  # never lost


def test_concurrent_same_role_drain_loses_no_lines(tmp_path):
    """Two same-role sessions draining the same holding file concurrently:
    exactly one wins the claim, the other no-ops. Across both inboxes the
    held lines appear exactly once total — none lost, none duplicated.
    """
    cfg = _make_cfg(tmp_path)
    # Queue several lines while NO backend-expert session is live, so they
    # land in the role holding inbox (not fanned out to live sessions).
    # Use unambiguous, non-prefix needles (L<i>END) so substring counts are exact.
    for i in range(20):
        I.send(cfg, "p", "S-coordinator", "backend-expert", f"L{i}END")
    # Now two same-role sessions spawn and both try to drain the holding file.
    _write_session_with_role(tmp_path, "p", "S-u-w1-p0", "backend-expert")
    _write_session_with_role(tmp_path, "p", "S-u-w2-p1", "backend-expert")

    barrier = threading.Barrier(2)

    def drain(sid):
        barrier.wait()
        I._drain_holding(cfg, "p", "backend-expert", sid)

    t1 = threading.Thread(target=drain, args=("S-u-w1-p0",))
    t2 = threading.Thread(target=drain, args=("S-u-w2-p1",))
    t1.start(); t2.start()
    t1.join(); t2.join()

    chat = tmp_path / "data" / "p" / "_chat"
    inbox1 = chat / "inbox-S-u-w1-p0.log"
    inbox2 = chat / "inbox-S-u-w2-p1.log"
    buf1 = inbox1.read_bytes() if inbox1.exists() else b""
    buf2 = inbox2.read_bytes() if inbox2.exists() else b""

    # Each of the 20 lines lands exactly once across the two inboxes.
    for i in range(20):
        needle = f"L{i}END".encode()
        total = buf1.count(needle) + buf2.count(needle)
        assert total == 1, f"L{i}END delivered {total} times (expected 1)"

    # Holding fully drained, no orphaned claims.
    holding = chat / "holding-backend-expert.log"
    assert not holding.exists() or holding.read_bytes() == b""
    assert list(chat.glob("holding-backend-expert.log.*.claim")) == []


def test_drain_holding_noop_when_nothing_held(tmp_path):
    """No holding file -> drain is a clean no-op (no inbox created/grown)."""
    cfg = _make_cfg(tmp_path)
    _write_session_with_role(tmp_path, "p", "S-u-x-p0", "x-expert")
    I._drain_holding(cfg, "p", "x-expert", "S-u-x-p0")
    inbox = tmp_path / "data" / "p" / "_chat" / "inbox-S-u-x-p0.log"
    assert not inbox.exists() or inbox.read_bytes() == b""


def test_role_routing_does_not_collide_with_sid(tmp_path):
    """Anything starting with S- is a literal SID, not a role keyword."""
    cfg = _make_cfg(tmp_path)
    _write_session_with_role(tmp_path, "p", "S-u-w1-p0", "backend-expert")
    # Send to literal SID — should NOT match by role even if role were set.
    out = I.send(cfg, "p", "S-c", "S-u-w1-p0", "hi")
    assert out["delivered_to"] == ["S-u-w1-p0"]
    # Send to role — should match.
    out = I.send(cfg, "p", "S-c", "backend-expert", "ho")
    assert out["delivered_to"] == ["S-u-w1-p0"]
