# Bot Swarm

A role-based, memory-augmented orchestration framework for Claude Code sessions. Successor in spirit to **bot-squad** — keeps its best primitives, replaces its operating model.

**Stage:** design discussion. No code yet. This document is the seed for the first implementation session.

---

## Origin and relationship to bot-squad

- **Canonical source of bot-squad:** `/home/almdudleer/bot-squad-mgmt/` (developed by user `almdudleer`).
- **Deployed:** `/home/www/bot-squad/`.

Bot-squad orchestrates Claude Code sessions in tmux panes via a FastAPI + worker + React UI stack. Each pane = a "bot." Each bot is bound to a **task** (via `task_id` + `extra_task_ids` in the session frontmatter). The "squad" is fan-out coordination across panes via a file-based intersession message bus.

Bot-swarm changes the binding: panes are bound to **persistent expert roles**, not tasks. Tasks flow through experts. The user mostly talks to a coordinator about **strategic initiatives**; the coordinator + a dedicated planner decompose initiatives into tasks and route them.

---

## Core direction

1. **Sessions ↔ roles, not sessions ↔ tasks.** A pane is a long-lived domain expert (frontend-expert, backend-expert, db-expert, researcher, etc.) that accumulates expertise over time.
2. **User interacts at the initiative level.** Strategic conversation with the coordinator; the coordinator/planner converts initiatives into concrete tasks. No micro-managing of individual tasks.
3. **Dynamic expert granularity.** Project scope drives composition. A simple backend gets one `backend-expert`; a DB-heavy project might split into `db-expert` + `api-expert` + `auth-expert`. The composition can change over the project's lifecycle.
4. **LLM-classification routing.** Each task is labeled with its target expert at planning time (the planner does this once, durably written into the task file). No per-task LLM call at dispatch.
5. **Sleep / memory compaction.** Periodically each expert (including the coordinator) summarizes recent work into persistent markdown memory, freeing live context. Memory survives pane death.
6. **Conflicts handled via the existing intersession mail bus.** Experts message each other and work it out. Add a soft-lock etiquette convention for file-write claims (see open questions).

---

## Top-level architecture

```
You ──talks about strategic initiative──▶ Coordinator
                                              │
                                              ▼
                                          Planner  (decomposes initiative → tasks,
                                                    LLM-labels each task with target expert)
                                              │
                                              ▼  task routed to expert (or new one spawned)
                                          Expert pane  (long-lived, role-bound)
                                              │
                                              ├──▶ mail bus ◀──▶ other experts (handoffs, conflicts)
                                              │
                                              └──▶ sleep cycle → memory/*.md files
                                                                 (coordinator + planner sleep too)
```

---

## Components

### Coordinator
- The main Claude session. The primary surface the user talks to.
- Holds project scope, vision, strategic context.
- Receives initiatives from the user, hands them to the planner for decomposition.
- Decides when to spawn / retire experts based on project shape.
- Sleeps too (it accumulates the most context: scope + every routing/spawn decision).

### Planner (dedicated expert)
- Decomposes initiatives into tasks.
- LLM-classifies each task → target expert (label written into the task file's frontmatter).
- Maintains its own memory of "how we usually break this kind of initiative down for this project."
- Sleeps separately from the coordinator so neither pane's context bloats with the other's detail.

### Experts (long-lived, role-bound)
- Each expert has: an `identity.md` (role description, responsibility sphere) + a `memory/` directory.
- Picks up tasks routed to them; works continuously in their domain.
- Talks to other experts via the mail bus for handoffs and conflicts.
- Periodically sleeps → memory files updated, pane resumed with slimmer context.

### Mail bus
- Reuse bot-squad's intersession primitive (`worker/bot_squad_worker/intersession.py` in bot-squad).
- Three operations: `send`, `inbox_read`, `inbox_wait`. Recipients are SIDs or role keywords.
- Extend `_resolve_recipients()` to know about new role keywords (`frontend`, `backend`, `db`, `researcher`, `planner`, `coordinator`, etc.).
- File-backed append-only log per pane: `data/<slug>/_chat/inbox-<sid>.log`.

### Sleep / memory compaction
- Per-expert markdown memory under `data/<slug>/experts/<role>/memory/`.
- A `MEMORY.md` index file (always loaded) points at topical memory files (architectural decisions, gotchas, recent work, etc.).
- On sleep: the expert (or a separate scribe pass) reads the recent conversation buffer, updates memory files, then the pane resumes with `identity.md` + `MEMORY.md` + relevant topical files re-loaded.
- **Format preference:** plain markdown over vector DB. Debuggable, human-editable, Claude reads it natively. Revisit vector DB only when markdown layout demonstrably can't answer a needed query.

---

## Initiative schema

Initiatives are first-class objects (not just strings on a session). Stored as markdown with YAML frontmatter:

```
data/<slug>/initiatives/I-0001-rebuild-onboarding.md
---
id: I-0001
title: Rebuild onboarding flow
status: active        # proposed | active | paused | done | abandoned
created_at: 2026-05-17
related_tasks: [T-0042, T-0043, T-0051]
---

## Goal
(why this initiative exists, in the user's words)

## Success criteria
- (concrete, checkable outcomes)
- ...

## Decisions log
- 2026-05-17 — decided X over Y because Z
- ...

## Notes
(free-form running context)
```

Tasks link back: each task's frontmatter carries `initiative_id: I-0001` + `assigned_role: frontend-expert`. Tasks inherit the "why" (goal + criteria) from their initiative.

---

## Data layout

```
data/<slug>/
  initiatives/
    I-0001-*.md
  backlog/
    T-0042.md                 # frontmatter: initiative_id, assigned_role, status, ...
  experts/
    coordinator/              # yes, the coordinator has memory like any expert
      identity.md
      memory/
        MEMORY.md
        project-scope.md
        routing-history.md
        ...
      recent.jsonl            # short-term buffer, drained on sleep
    planner/
      identity.md
      memory/...
    frontend-expert/
      identity.md
      memory/...
    backend-expert/
      identity.md
      memory/...
    _archive/                 # retired experts' memory parked for possible revival
      old-monolith-expert/
        memory/...
  _chat/
    inbox-<sid>.log           # intersession mail bus (reuse from bot-squad)
  _worker/
    heartbeat
    ...
```

---

## What reuses bot-squad as-is

- **Pane-as-session substrate** (`worker/bot_squad_worker/sessions.py`): tmux pane spawn / pause / resume, with `claude_uuid` discovery for history rehydration. Swap the `task_id` field for a `role` field in the session frontmatter.
- **Intersession mail bus** (`worker/bot_squad_worker/intersession.py`): used as-is for cross-expert communication. Extend the role-keyword routing map.
- **File-based state**: continue under `data/<slug>/` with the new layout above.
- **API + worker + React UI stack** (FastAPI + APScheduler-driven worker + Vite/React): same shape. New endpoints/pages: initiative CRUD, expert roster view, memory browser, sleep status.
- **Telegram notifications**: keep, point at the new event set (initiative status changes, expert spawn/retire, conflict escalations).

---

## What is new

- **Coordinator** as a top-level strategic pane (no equivalent in bot-squad — its `autonomous` orchestrator is paused/frozen and was scoped narrower).
- **Planner** as a dedicated expert role with its own memory.
- **Persistent per-expert markdown memory** with a sleep cycle. (Bot-squad has Claude's per-session `.jsonl` but no compaction beyond what Claude Code does internally.)
- **Initiative-as-object** with full schema (goal, success criteria, status, related tasks, decisions log). Bot-squad has `initiative` only as a string in session frontmatter.
- **Expert lifecycle operations**: spawn, retire, possibly split — driven by coordinator decisions.

---

## Open design questions (deferred — decide before / during implementation)

1. **Sleep trigger.** Time-based (nightly), threshold-based (.jsonl size / token count), task-boundary, or coordinator-initiated? Likely a hybrid; start simple (coordinator-initiated + a generous threshold safety net).
2. **Expert lifecycle mechanics.**
   - Split (`backend-expert` → `db-expert` + `api-expert`): how is memory partitioned between the new specialists? Probably a special "split sleep" where the old expert assigns each memory chunk to one of the successors.
   - Retire: dormant (resumable in place) or archived (move memory under `_archive/`)? Start with archive — cheap and reversible.
   - Merge: probably skip in v1. Only implement when actually needed.
3. **File-conflict soft-lock convention.** Mail bus alone won't prevent two experts editing the same file simultaneously. Suggested cheapest fix: before opening a file for writing, expert posts `"claiming <path>"` to the bus and waits ~30s for objections. Etiquette, not a real lock.
4. **Initiative ID format.** `I-NNNN` zero-padded is simplest. Match the task scheme (bot-squad uses `T-NNNN`).
5. **Coordinator's memory shape.** What goes in its `MEMORY.md`? Strategic decisions, user preferences, the active initiative set, expert roster, routing history. Needs more sketching when first implemented.

---

## Suggested next steps

1. Decide whether to **fork bot-squad-mgmt and modify** or **start fresh and reuse selectively**. Recommendation: fork — most plumbing is already there, you'll mostly be editing/replacing the orchestration layer.
2. Sketch the **coordinator's first conversation** with a user (a worked example of "I want to build X" → initiative → tasks → routing → experts spawned). Pin down what's awkward before writing code.
3. Implement **role-based session metadata + experts directory layout** first (smallest change with the most leverage — everything else builds on it).
4. Implement **per-expert memory + the sleep cycle** next. The hardest part is making sleep produce *good* memory; iterate by reading what gets written.
5. Add **coordinator + planner** with hand-coded routing logic, then introduce LLM classification once you've seen how a few real tasks shake out.
